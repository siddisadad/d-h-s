class AppConfig {
  static const String devBaseUrl = 'http://localhost:8080/api/v1';
  static const String prodBaseUrl = 'https://api.deshmukh-erp.com/v1';
  
  static String get baseUrl => devBaseUrl; // Default to dev
}
