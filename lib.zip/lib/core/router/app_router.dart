import 'package:flutter/foundation.dart';
import 'package:go_router/go_router.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../features/authentication/presentation/providers/auth_provider.dart';
import '../../features/authentication/presentation/screens/splash_screen.dart';
import '../../features/authentication/presentation/screens/login_screen.dart';
import '../../features/dashboard/presentation/screens/dashboard_screen.dart';
import '../../features/inventory/presentation/screens/inventory_screen.dart';
import '../../features/sales/presentation/screens/sales_invoice_screen.dart';
import '../../features/purchases/presentation/screens/purchases_screen.dart';
import '../../features/crm/presentation/screens/customer_ledger_screen.dart';
import '../../features/crm/presentation/screens/supplier_directory_screen.dart';
import '../../features/finance/presentation/screens/finance_screen.dart';
import '../../features/analytics/presentation/screens/analytics_screen.dart';
import '../../features/settings/presentation/screens/settings_screen.dart';
import '../../features/employees/presentation/screens/employee_list_screen.dart';

import '../providers/startup_provider.dart';
import 'router_notifier.dart';

part 'app_router.g.dart';

@riverpod
GoRouter appRouterWidget(AppRouterWidgetRef ref) {
  final notifier = ref.read(routerNotifierProvider.notifier);

  return GoRouter(
    initialLocation: '/splash',
    debugLogDiagnostics: true,
    refreshListenable: notifier,
    redirect: (context, state) {
      final authState = ref.read(authProvider);
      final startupAsync = ref.read(startupProvider);

      debugPrint('🛣️ Router Redirect: path=${state.uri.path}, auth=${authState != null}, startup=${startupAsync.hasValue}');

      // 1. Handle Startup
      if (startupAsync.isLoading || startupAsync.hasError) {
        if (state.uri.path == '/splash') return null;
        return '/splash';
      }

      final isSplash = state.uri.path == '/splash';
      final isLogin = state.uri.path == '/login';

      // 2. Handle Auth
      if (authState == null) {
        if (isLogin) return null;
        if (isSplash && startupAsync.isLoading) return null;
        return '/login';
      }

      // 3. Authenticated - Redirect from Auth screens to Dashboard
      if (isSplash || isLogin) {
        return '/dashboard';
      }

      return null;
    },
    routes: [
      GoRoute(
        path: '/splash',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/dashboard',
        builder: (context, state) => const DashboardScreen(),
      ),
      GoRoute(
        path: '/inventory',
        builder: (context, state) => const InventoryScreen(),
      ),
      GoRoute(
        path: '/sales',
        builder: (context, state) => const SalesInvoiceScreen(),
      ),
      GoRoute(
        path: '/purchases',
        builder: (context, state) => const PurchasesScreen(),
      ),
      GoRoute(
        path: '/customers',
        builder: (context, state) => const CustomerLedgerScreen(),
      ),
      GoRoute(
        path: '/suppliers',
        builder: (context, state) => const SupplierDirectoryScreen(),
      ),
      GoRoute(
        path: '/finance',
        builder: (context, state) => const FinanceScreen(),
      ),
      GoRoute(
        path: '/analytics',
        builder: (context, state) => const AnalyticsScreen(),
      ),
      GoRoute(
        path: '/settings',
        builder: (context, state) => const SettingsScreen(),
      ),
      GoRoute(
        path: '/employees',
        builder: (context, state) => const EmployeeListScreen(),
      ),
    ],
  );
}
