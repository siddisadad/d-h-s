import 'package:flutter/material.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../features/authentication/presentation/providers/auth_provider.dart';
import '../providers/startup_provider.dart';

part 'router_notifier.g.dart';

@riverpod
class RouterNotifier extends _$RouterNotifier implements Listenable {
  VoidCallback? _listener;

  @override
  void build() {
    // Listen to relevant states and trigger listener
    ref.listen(authProvider, (_, __) => _listener?.call());
    ref.listen(startupProvider, (_, __) => _listener?.call());
  }

  @override
  void addListener(VoidCallback listener) {
    _listener = listener;
  }

  @override
  void removeListener(VoidCallback listener) {
    _listener = null;
  }
}
