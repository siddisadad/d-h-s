import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/authentication/presentation/providers/auth_provider.dart';

enum UserRole { admin, manager, employee }

class PermissionWrapper extends ConsumerWidget {
  final List<String> allowedRoles;
  final Widget child;
  final Widget? fallback;

  const PermissionWrapper({
    super.key,
    required this.allowedRoles,
    required this.child,
    this.fallback,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider);
    
    if (user != null && allowedRoles.contains(user.role)) {
      return child;
    }
    
    return fallback ?? const SizedBox.shrink();
  }
}
