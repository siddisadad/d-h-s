import 'package:flutter/foundation.dart';
import '../../features/dashboard/data/datasources/dashboard_remote_data_source.dart';
import '../../features/dashboard/data/repositories/dashboard_repository_impl.dart';
import '../../features/dashboard/domain/usecases/get_dashboard_stats.dart';
import '../../features/crm/data/datasources/crm_remote_data_source.dart';
import '../../features/crm/data/repositories/crm_repository_impl.dart';
import '../../features/crm/domain/usecases/get_contacts.dart';
import '../../features/inventory/data/datasources/inventory_remote_data_source.dart';
import '../../features/inventory/data/repositories/inventory_repository_impl.dart';
import '../../features/inventory/domain/usecases/get_products.dart';
import '../../features/sales/data/datasources/sales_remote_data_source.dart';
import '../../features/sales/data/repositories/sales_repository_impl.dart';
import '../../features/sales/domain/usecases/create_invoice.dart';
import '../../features/purchases/data/repositories/purchase_repository_impl.dart';
import '../network/api_client.dart';

class InjectionContainer {
  static final InjectionContainer _instance = InjectionContainer._internal();
  factory InjectionContainer() => _instance;
  InjectionContainer._internal();

  bool _isInitialized = false;

  // Use Cases / Repositories bridge
  late GetProducts getProductsUseCase;
  late GetDashboardStats getStatsUseCase;
  late CreateInvoice createInvoiceUseCase;
  late GetContacts getContactsUseCase;
  late PurchaseRepositoryImpl purchaseRepository;

  void init() {
    if (_isInitialized) {
      debugPrint('📦 [DI] Service Locator already initialized');
      return;
    }

    debugPrint('📦 [DI] Initializing Service Locator...');

    // Core
    final client = apiClient;

    // Inventory
    // Swapping Mock with real API Implementation
    final inventoryDataSource = InventoryRemoteDataSourceImpl(client);
    final inventoryRepository = InventoryRepositoryImpl(remoteDataSource: inventoryDataSource);
    getProductsUseCase = GetProducts(inventoryRepository);

    // Dashboard
    final dashboardDataSource = DashboardMockDataSourceImpl();
    final dashboardRepository = DashboardRepositoryImpl(remoteDataSource: dashboardDataSource);
    getStatsUseCase = GetDashboardStats(dashboardRepository);

    // Sales
    final salesDataSource = SalesMockDataSourceImpl();
    final salesRepository = SalesRepositoryImpl(remoteDataSource: salesDataSource);
    createInvoiceUseCase = CreateInvoice(salesRepository);

    // CRM
    final crmDataSource = CrmMockDataSourceImpl();
    final crmRepository = CrmRepositoryImpl(remoteDataSource: crmDataSource);
    getContactsUseCase = GetContacts(crmRepository);

    // Purchases
    purchaseRepository = PurchaseRepositoryImpl();

    _isInitialized = true;
    debugPrint('✅ [DI] Service Locator Ready');
  }
}

final sl = InjectionContainer();
