import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:flutter/foundation.dart';
import '../di/injection_container.dart';
import '../database/local_database.dart';

part 'startup_provider.g.dart';

@riverpod
Future<void> startup(StartupRef ref) async {
  debugPrint('🚀 [Startup] Beginning sequence...');
  
  try {
    // 1. Initialize Service Locator (Legacy bridge)
    debugPrint('📦 [Startup] Step 1: Initializing Service Locator...');
    sl.init();

    // 2. Initialize Database
    debugPrint('💾 [Startup] Step 2: Initializing Database...');
    // Ensure the database is ready by awaiting its build
    await ref.watch(localDatabaseProvider);
    debugPrint('💾 [Startup] Database Ready');

    // 3. Artificial delay for Splash branding
    debugPrint('⏳ [Startup] Step 3: Artificial delay for branding...');
    await Future.delayed(const Duration(seconds: 2));
    
    debugPrint('✅ [Startup] Complete!');
  } catch (e, stack) {
    debugPrint('❌ [Startup] Critical Failure: $e');
    debugPrint(stack.toString());
    rethrow;
  }
}
