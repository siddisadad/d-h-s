import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../database/local_database.dart';
import 'package:drift/drift.dart';

part 'global_search_provider.g.dart';

enum SearchCategory { product, customer, supplier, invoice }

class SearchResult {
  final String id;
  final String title;
  final String subtitle;
  final SearchCategory category;
  final String path;

  SearchResult({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.category,
    required this.path,
  });
}

@riverpod
class GlobalSearch extends _$GlobalSearch {
  @override
  AsyncValue<List<SearchResult>> build() {
    return const AsyncData([]);
  }

  Future<void> search(String query) async {
    if (query.length < 2) {
      state = const AsyncData([]);
      return;
    }

    state = const AsyncLoading();
    
    final db = ref.read(localDatabaseProvider);
    final results = <SearchResult>[];

    final keyword = '%$query%';

    // 1. Search Products
    final productRows = await (db.select(db.products)
          ..where((t) => t.name.like(keyword) | t.sku.like(keyword)))
        .get();
    results.addAll(productRows.map((r) => SearchResult(
          id: r.sku,
          title: r.name,
          subtitle: 'Stock: ${r.stock} ${r.unit}',
          category: SearchCategory.product,
          path: '/inventory',
        )));

    // 2. Search Contacts (Customers & Suppliers)
    final contactRows = await (db.select(db.contacts)
          ..where((t) => t.name.like(keyword) | t.gstin.like(keyword)))
        .get();
    results.addAll(contactRows.map((r) => SearchResult(
          id: r.id,
          title: r.name,
          subtitle: r.location,
          category: r.type == 'customer' ? SearchCategory.customer : SearchCategory.supplier,
          path: r.type == 'customer' ? '/customers' : '/suppliers',
        )));

    // 3. Search Invoices
    final invoiceRows = await (db.select(db.invoices)
          ..where((t) => t.id.like(keyword) | t.customerName.like(keyword)))
        .get();
    results.addAll(invoiceRows.map((r) => SearchResult(
          id: r.id,
          title: 'Invoice #${r.id}',
          subtitle: r.customerName,
          category: SearchCategory.invoice,
          path: '/sales',
        )));

    state = AsyncData(results);
  }
}
