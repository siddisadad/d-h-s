import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'local_database.g.dart';

class Products extends Table {
  TextColumn get sku => text().withLength(min: 1, max: 50)();
  TextColumn get name => text()();
  TextColumn get category => text()();
  TextColumn get price => text()();
  TextColumn get stock => text()();
  TextColumn get unit => text()();
  BoolColumn get isLowStock => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {sku};
}

class Activities extends Table {
  TextColumn get id => text()();
  TextColumn get title => text()();
  TextColumn get subtitle => text()();
  DateTimeColumn get timestamp => dateTime()();
  TextColumn get type => text()();

  @override
  Set<Column> get primaryKey => {id};
}

class Employees extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get role => text()();
  TextColumn get email => text()();
  TextColumn get phone => text()();
  TextColumn get salary => text()();
  TextColumn get attendanceStatus => text().withDefault(const Constant('Present'))();

  @override
  Set<Column> get primaryKey => {id};
}

class Contacts extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get initials => text()();
  TextColumn get contact => text()();
  TextColumn get gstin => text()();
  TextColumn get balance => text()();
  TextColumn get location => text()();
  TextColumn get type => text()(); // 'customer' or 'supplier'

  @override
  Set<Column> get primaryKey => {id};
}

class Invoices extends Table {
  TextColumn get id => text()();
  TextColumn get customerName => text()();
  DateTimeColumn get date => dateTime()();
  RealColumn get subtotal => real()();
  RealColumn get totalGst => real()();
  RealColumn get discount => real()();
  RealColumn get grandTotal => real()();

  @override
  Set<Column> get primaryKey => {id};
}

class Transactions extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get title => text()();
  TextColumn get category => text()(); // 'Income' or 'Expense'
  RealColumn get amount => real()();
  DateTimeColumn get date => dateTime()();
  TextColumn get paymentMode => text()(); // 'Cash', 'Bank', 'UPI'
}

@DriftDatabase(tables: [Products, Activities, Employees, Contacts, Invoices, Transactions])
class LocalDatabase extends _$LocalDatabase {
  LocalDatabase() : super(_openConnection());

  @override
  int get schemaVersion => 3;

  @override
  MigrationStrategy get migration {
    return MigrationStrategy(
      onCreate: (m) async {
        await m.createAll();
      },
      onUpgrade: (m, from, to) async {
        if (from < 2) {
          await m.createTable(contacts);
          await m.createTable(invoices);
        }
        if (from < 3) {
          await m.createTable(transactions);
        }
      },
    );
  }

  static QueryExecutor _openConnection() {
    return driftDatabase(
      name: 'dhs_erp_v2',
      web: DriftWebOptions(
        sqlite3Wasm: Uri.parse('sqlite3.wasm'),
        driftWorker: Uri.parse('drift_worker.js'),
      ),
    );
  }
}

@Riverpod(keepAlive: true)
LocalDatabase localDatabase(LocalDatabaseRef ref) {
  final db = LocalDatabase();
  ref.onDispose(db.close);
  return db;
}
