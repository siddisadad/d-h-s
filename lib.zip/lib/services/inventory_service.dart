class Product {
  final String name;
  final String sku;
  final String category;
  final String price;
  final String stock;
  final String unit;
  final bool lowStock;

  Product({
    required this.name,
    required this.sku,
    required this.category,
    required this.price,
    required this.stock,
    required this.unit,
    required this.lowStock,
  });
}

class InventoryService {
  static InventoryService? _instance;
  static InventoryService get instance => _instance ??= InventoryService._();
  InventoryService._();

  final List<Product> _mockProducts = [
    Product(
      category: 'Steel',
      name: 'Tata Tiscon TMT Bars 12mm',
      price: '₹68.50',
      sku: 'STEEL-TT-12',
      stock: '4,200',
      unit: 'Kg',
      lowStock: false,
    ),
    Product(
      category: 'Power Tools',
      name: 'Bosch Professional Drill 750W',
      price: '₹4,250',
      sku: 'TOOL-BOS-750',
      stock: '8',
      unit: 'Piece',
      lowStock: true,
    ),
    Product(
      category: 'Plumbing',
      name: 'Copper Pipe 1 inch (Standard)',
      price: '₹210',
      sku: 'PLUMB-COP-1',
      stock: '150',
      unit: 'Meter',
      lowStock: false,
    ),
    Product(
      category: 'Electrical',
      name: 'Havells 1.5mm Double Core Wire',
      price: '₹1,120',
      sku: 'ELEC-HAV-15',
      stock: '45',
      unit: 'Reel',
      lowStock: false,
    ),
  ];

  Future<List<Product>> getProducts({String? category}) async {
    await Future.delayed(const Duration(milliseconds: 300));
    if (category == null || category.isEmpty || category == 'All Items') {
      return _mockProducts;
    }
    return _mockProducts
        .where((p) => p.category.toLowerCase() == category.toLowerCase())
        .toList();
  }

  Future<Product?> getProductBySku(String sku) async {
    await Future.delayed(const Duration(milliseconds: 200));
    try {
      return _mockProducts.firstWhere((p) => p.sku == sku);
    } catch (_) {
      return null;
    }
  }
}
