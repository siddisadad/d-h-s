class Transaction {
  final String title;
  final String id;
  final String time;
  final String amount;
  final bool isPurchase;

  Transaction({
    required this.title,
    required this.id,
    required this.time,
    required this.amount,
    required this.isPurchase,
  });
}

class InvoiceService {
  static InvoiceService? _instance;
  static InvoiceService get instance => _instance ??= InvoiceService._();
  InvoiceService._();

  Future<bool> createInvoice(Map<String, dynamic> invoiceData) async {
    await Future.delayed(const Duration(seconds: 2)); // Simulate processing
    return true;
  }

  Future<List<Transaction>> getRecentTransactions() async {
    await Future.delayed(const Duration(milliseconds: 400));
    return [
      Transaction(
        title: 'Sai Construction & Builders',
        id: 'INV-9021',
        time: '10:45 AM',
        amount: '₹42,500',
        isPurchase: false,
      ),
      Transaction(
        title: 'Tata Steel Ltd.',
        id: 'PO-4412',
        time: '09:15 AM',
        amount: '₹1,20,000',
        isPurchase: true,
      ),
    ];
  }

  Future<bool> generatePdfSimulation() async {
    await Future.delayed(const Duration(seconds: 2));
    return true;
  }
}
