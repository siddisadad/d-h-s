class KPIResult {
  final String sales;
  final String purchases;
  final String collections;
  final String lowStock;

  KPIResult({
    required this.sales,
    required this.purchases,
    required this.collections,
    required this.lowStock,
  });
}

class DashboardService {
  static DashboardService? _instance;
  static DashboardService get instance => _instance ??= DashboardService._();
  DashboardService._();

  Future<KPIResult> getKPIs() async {
    // Simulating API delay
    await Future.delayed(const Duration(milliseconds: 500));
    
    return KPIResult(
      sales: '₹1,45,200',
      purchases: '₹82,400',
      collections: '₹92,000',
      lowStock: '14 Items',
    );
  }

  Future<List<double>> getRevenueTrend() async {
    return [45.0, 52.0, 48.0, 70.0, 61.0, 85.0, 92.0];
  }
}
