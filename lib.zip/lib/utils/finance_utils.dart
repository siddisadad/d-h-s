import 'package:intl/intl.dart';

class FinanceUtils {
  /// Calculates the GST amount for a given base amount and rate.
  static double calculateGst(double baseAmount, double gstRate) {
    if (baseAmount < 0 || gstRate < 0) return 0.0;
    return (baseAmount * gstRate) / 100;
  }

  /// Calculates the total amount including GST.
  static double calculateTotalWithGst(double baseAmount, double gstRate) {
    if (baseAmount < 0) return 0.0;
    return baseAmount + calculateGst(baseAmount, gstRate);
  }

  /// Applies a discount to a total amount.
  /// If [isPercentage] is true, [discount] is treated as a percentage (0-100).
  /// If [isPercentage] is false, [discount] is treated as a flat amount.
  static double applyDiscount(double total, double discount,
      {bool isPercentage = false}) {
    if (total <= 0) return 0.0;
    if (discount <= 0) return total;

    double discountAmount;
    if (isPercentage) {
      discountAmount = (total * discount) / 100;
    } else {
      discountAmount = discount;
    }

    final result = total - discountAmount;
    return result < 0 ? 0.0 : result;
  }

  /// Formats a double amount into Indian Rupee (INR) currency string.
  /// Example: 100000.0 -> ₹1,00,000.00
  static String formatIndianCurrency(double amount) {
    final formatter = NumberFormat.currency(
      locale: 'en_IN',
      symbol: '₹',
      decimalDigits: 2,
    );
    return formatter.format(amount);
  }

  /// Formats large amounts into Lakhs or Crores representation.
  /// Example: 4250000.0 -> ₹42.5L
  static String formatLakhs(double amount) {
    if (amount >= 10000000) {
      return '₹${(amount / 10000000).toStringAsFixed(1)}Cr';
    } else if (amount >= 100000) {
      return '₹${(amount / 100000).toStringAsFixed(1)}L';
    }
    return formatIndianCurrency(amount);
  }

  /// Splits GST into CGST and SGST (standard 50/50 split).
  static Map<String, double> calculateTaxBreakdown(double totalGst) {
    return {
      'CGST': totalGst / 2,
      'SGST': totalGst / 2,
    };
  }

  /// Calculates the breakdown for an invoice summary.
  static Map<String, double> calculateSummary({
    required List<Map<String, dynamic>> items,
    double discount = 0.0,
    bool isDiscountPercentage = false,
  }) {
    double subtotal = 0.0;
    double totalGst = 0.0;

    for (var item in items) {
      final double price = (item['price'] as num?)?.toDouble() ?? 0.0;
      final double qty = (item['qty'] as num?)?.toDouble() ?? 0.0;
      final double gstRate = (item['gstRate'] as num?)?.toDouble() ?? 0.0;

      final itemBase = price * qty;
      subtotal += itemBase;
      totalGst += calculateGst(itemBase, gstRate);
    }

    final totalBeforeDiscount = subtotal + totalGst;
    final grandTotal = applyDiscount(
      totalBeforeDiscount,
      discount,
      isPercentage: isDiscountPercentage,
    );

    return {
      'subtotal': subtotal,
      'totalGst': totalGst,
      'discountAmount': totalBeforeDiscount - grandTotal,
      'grandTotal': grandTotal,
    };
  }
}
