import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:deshmukh_steel_e_r_p/features/employees/domain/entities/employee.dart' as employee_entity;
import '../../../../core/database/local_database.dart';
import 'package:drift/drift.dart';

part 'employee_provider.g.dart';

@riverpod
class EmployeeNotifier extends _$EmployeeNotifier {
  @override
  Future<List<employee_entity.Employee>> build() async {
    return _loadEmployees();
  }

  Future<List<employee_entity.Employee>> _loadEmployees() async {
    final db = ref.watch(localDatabaseProvider);
    final rows = await db.select(db.employees).get();
    
    if (rows.isEmpty) {
      final initialEmployees = [
        employee_entity.Employee(id: 'E001', name: 'Rahul Sharma', role: 'Sales Manager', email: 'rahul@dhs.com', phone: '9876543210', salary: '45,000'),
        employee_entity.Employee(id: 'E002', name: 'Priya Patel', role: 'Inventory Specialist', email: 'priya@dhs.com', phone: '9876543211', salary: '35,000'),
        employee_entity.Employee(id: 'E003', name: 'Amit Kumar', role: 'Warehouse Operative', email: 'amit@dhs.com', phone: '9876543212', salary: '25,000'),
      ];

      for (final e in initialEmployees) {
        await db.into(db.employees).insert(
          EmployeesCompanion.insert(
            id: e.id,
            name: e.name,
            role: e.role,
            email: e.email,
            phone: e.phone,
            salary: e.salary,
            attendanceStatus: Value(e.attendanceStatus),
          ),
        );
      }
      return initialEmployees;
    }

    return rows.map((row) => employee_entity.Employee(
      id: row.id,
      name: row.name,
      role: row.role,
      email: row.email,
      phone: row.phone,
      salary: row.salary,
      attendanceStatus: row.attendanceStatus,
    )).toList();
  }

  Future<void> updateAttendance(String id, String status) async {
    final db = ref.read(localDatabaseProvider);
    await (db.update(db.employees)..where((t) => t.id.equals(id))).write(
      EmployeesCompanion(attendanceStatus: Value(status)),
    );
    ref.invalidateSelf();
  }

  Future<void> addEmployee(employee_entity.Employee employee) async {
    final db = ref.read(localDatabaseProvider);
    await db.into(db.employees).insert(
      EmployeesCompanion.insert(
        id: employee.id,
        name: employee.name,
        role: employee.role,
        email: employee.email,
        phone: employee.phone,
        salary: employee.salary,
        attendanceStatus: Value(employee.attendanceStatus),
      ),
    );
    ref.invalidateSelf();
  }
}
