// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'employee_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$employeeNotifierHash() => r'0ded17d095434ca8eb4f292345a747c4d0ef24dd';

/// See also [EmployeeNotifier].
@ProviderFor(EmployeeNotifier)
final employeeNotifierProvider = AutoDisposeAsyncNotifierProvider<
    EmployeeNotifier, List<employee_entity.Employee>>.internal(
  EmployeeNotifier.new,
  name: r'employeeNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$employeeNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EmployeeNotifier
    = AutoDisposeAsyncNotifier<List<employee_entity.Employee>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
