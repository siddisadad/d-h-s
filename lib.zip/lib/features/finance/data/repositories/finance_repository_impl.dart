import 'package:deshmukh_steel_e_r_p/core/error/failures.dart';
import 'package:deshmukh_steel_e_r_p/core/error/result.dart';
import 'package:deshmukh_steel_e_r_p/features/finance/domain/entities/cash_entry.dart';
import 'package:deshmukh_steel_e_r_p/features/finance/domain/repositories/finance_repository.dart';

class FinanceRepositoryImpl implements FinanceRepository {
  @override
  Future<Result<List<CashEntry>>> getCashBook() async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      return Result.success([
        CashEntry(date: '25 Oct', description: 'Office Rent', amount: '₹12,000', isIncome: false),
        CashEntry(date: '24 Oct', description: 'Invoice #9021', amount: '₹42,500', isIncome: true),
      ]);
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }
}
