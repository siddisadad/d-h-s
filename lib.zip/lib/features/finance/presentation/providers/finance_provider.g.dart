// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'finance_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$financeNotifierHash() => r'563b18427011056968c4829bb4c160aba5f77562';

/// See also [FinanceNotifier].
@ProviderFor(FinanceNotifier)
final financeNotifierProvider = AutoDisposeAsyncNotifierProvider<
    FinanceNotifier, List<Transaction>>.internal(
  FinanceNotifier.new,
  name: r'financeNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$financeNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$FinanceNotifier = AutoDisposeAsyncNotifier<List<Transaction>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
