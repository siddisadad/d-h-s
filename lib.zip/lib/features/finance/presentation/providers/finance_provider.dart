import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../../../core/database/local_database.dart';
import 'package:drift/drift.dart';

part 'finance_provider.g.dart';

@riverpod
class FinanceNotifier extends _$FinanceNotifier {
  @override
  Future<List<Transaction>> build() async {
    return _loadTransactions();
  }

  Future<List<Transaction>> _loadTransactions() async {
    final db = ref.watch(localDatabaseProvider);
    final rows = await (db.select(db.transactions)..orderBy([(t) => OrderingTerm(expression: t.date, mode: OrderingMode.desc)])).get();
    
    if (rows.isEmpty) {
      // Mock initial data
      final initial = [
        TransactionsCompanion.insert(title: 'Sale - INV001', category: 'Income', amount: 45000, date: DateTime.now(), paymentMode: 'Cash'),
        TransactionsCompanion.insert(title: 'Salary Payment', category: 'Expense', amount: 12000, date: DateTime.now().subtract(const Duration(days: 1)), paymentMode: 'Bank'),
        TransactionsCompanion.insert(title: 'Electricity Bill', category: 'Expense', amount: 3500, date: DateTime.now().subtract(const Duration(days: 2)), paymentMode: 'UPI'),
      ];
      for (var t in initial) {
        await db.into(db.transactions).insert(t);
      }
      return _loadTransactions();
    }
    return rows;
  }

  Future<void> addTransaction({
    required String title,
    required String category,
    required double amount,
    required String paymentMode,
  }) async {
    final db = ref.read(localDatabaseProvider);
    await db.into(db.transactions).insert(
      TransactionsCompanion.insert(
        title: title,
        category: category,
        amount: amount,
        date: DateTime.now(),
        paymentMode: paymentMode,
      ),
    );
    ref.invalidateSelf();
  }
}
