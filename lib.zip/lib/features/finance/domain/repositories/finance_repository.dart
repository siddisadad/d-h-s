import '../../../../core/error/result.dart';
import '../entities/cash_entry.dart';

abstract class FinanceRepository {
  Future<Result<List<CashEntry>>> getCashBook();
}
