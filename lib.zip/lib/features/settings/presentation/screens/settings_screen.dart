import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../../../../core/design_system/theme/app_theme.dart';
import '../../../../core/widgets/custom_card.dart';
import '../../../authentication/presentation/providers/auth_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tokens = context.tokens;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('SETTINGS'),
      ),
      body: ListView(
        padding: EdgeInsets.all(tokens.space24),
        children: [
          _buildSectionHeader(context, 'General'),
          CustomCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text('Dark Mode'),
                  value: Theme.of(context).brightness == Brightness.dark,
                  onChanged: (val) {},
                  activeThumbColor: AppColors.primary,
                ),
                const Divider(height: 1),
                ListTile(
                  title: const Text('Language'),
                  trailing: const Text('English (US)', style: TextStyle(fontWeight: FontWeight.w600)),
                  onTap: () {},
                ),
              ],
            ),
          ),
          SizedBox(height: tokens.space32),
          _buildSectionHeader(context, 'Data Management'),
          CustomCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.cloud_upload_outlined, color: AppColors.primary),
                  title: const Text('Export Backup'),
                  subtitle: const Text('Save database to local storage'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => _exportBackup(context),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.cloud_download_outlined, color: AppColors.success),
                  title: const Text('Restore Data'),
                  subtitle: const Text('Import data from a backup file'),
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a file to restore...')));
                  },
                ),
              ],
            ),
          ),
          SizedBox(height: tokens.space32),
          _buildSectionHeader(context, 'Account'),
          CustomCard(
            padding: EdgeInsets.zero,
            child: ListTile(
              leading: const Icon(Icons.logout_rounded, color: AppColors.error),
              title: const Text('Sign Out', style: TextStyle(color: AppColors.error, fontWeight: FontWeight.w600)),
              onTap: () => ref.read(authProvider.notifier).logout(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, left: 4),
      child: Text(
        title.toUpperCase(),
        style: context.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w700, letterSpacing: 1.2),
      ),
    );
  }

  Future<void> _exportBackup(BuildContext context) async {
    try {
      final dbFolder = await getApplicationDocumentsDirectory();
      // Use the actual name from local_database.dart: driftDatabase(name: 'dhs_erp_v2')
      final dbFile = File(p.join(dbFolder.path, 'dhs_erp_v2.sqlite')); 
      
      if (!await dbFile.exists()) {
        throw Exception('Database file not found at ${dbFile.path}');
      }

      final backupDir = await getDownloadsDirectory() ?? dbFolder;
      final backupFile = File(p.join(backupDir.path, 'DHS_ERP_Backup_${DateTime.now().millisecondsSinceEpoch}.db'));
      
      await dbFile.copy(backupFile.path);
      
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Backup saved to: ${backupFile.path}')),
        );
      }
    } catch (e) {
       if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Backup Failed: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }
}
