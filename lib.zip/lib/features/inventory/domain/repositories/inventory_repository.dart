import '../../../../core/error/result.dart';
import '../entities/product.dart';

abstract class InventoryRepository {
  Future<Result<List<Product>>> getProducts({String? category});
  Future<Result<Product>> getProductBySku(String sku);
}
