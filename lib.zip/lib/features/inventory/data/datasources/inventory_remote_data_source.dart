import '../../../../core/network/api_client.dart';
import '../../domain/entities/product.dart';
import '../models/product_model.dart';

abstract class InventoryRemoteDataSource {
  Future<List<Product>> getProducts({String? category});
  Future<Product> getProductBySku(String sku);
}

class InventoryRemoteDataSourceImpl implements InventoryRemoteDataSource {
  final ApiClient _client;

  InventoryRemoteDataSourceImpl(this._client);

  @override
  Future<List<Product>> getProducts({String? category}) async {
    final response = await _client.dio.get(
      '/products',
      queryParameters: category != null ? {'category': category} : null,
    );

    if (response.statusCode == 200) {
      final List<dynamic> data = response.data;
      return data.map((json) => ProductModel.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load products');
    }
  }

  @override
  Future<Product> getProductBySku(String sku) async {
    final response = await _client.dio.get('/products/$sku');

    if (response.statusCode == 200) {
      return ProductModel.fromJson(response.data);
    } else {
      throw Exception('Product not found');
    }
  }
}

class InventoryMockDataSourceImpl implements InventoryRemoteDataSource {
  final List<Product> _mockProducts = [
    Product(
      category: 'Steel',
      name: 'Tata Tiscon TMT Bars 12mm',
      price: '₹68.50',
      sku: 'STEEL-TT-12',
      stock: '4,200',
      unit: 'Kg',
      isLowStock: false,
    ),
    Product(
      category: 'Power Tools',
      name: 'Bosch Professional Drill 750W',
      price: '₹4,250',
      sku: 'TOOL-BOS-750',
      stock: '8',
      unit: 'Piece',
      isLowStock: true,
    ),
    Product(
      category: 'Plumbing',
      name: 'Copper Pipe 1 inch (Standard)',
      price: '₹210',
      sku: 'PLUMB-COP-1',
      stock: '150',
      unit: 'Meter',
      isLowStock: false,
    ),
    Product(
      category: 'Electrical',
      name: 'Havells 1.5mm Double Core Wire',
      price: '₹1,120',
      sku: 'ELEC-HAV-15',
      stock: '45',
      unit: 'Reel',
      isLowStock: false,
    ),
  ];

  @override
  Future<List<Product>> getProducts({String? category}) async {
    await Future.delayed(const Duration(milliseconds: 300));
    if (category == null || category.isEmpty || category == 'All Items') {
      return _mockProducts;
    }
    return _mockProducts
        .where((p) => p.category.toLowerCase() == category.toLowerCase())
        .toList();
  }

  @override
  Future<Product> getProductBySku(String sku) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _mockProducts.firstWhere((p) => p.sku == sku);
  }
}
