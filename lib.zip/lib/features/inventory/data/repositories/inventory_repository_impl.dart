import '../../../../core/error/failures.dart';
import '../../../../core/error/result.dart';
import '../../domain/entities/product.dart';
import '../../domain/repositories/inventory_repository.dart';
import '../datasources/inventory_remote_data_source.dart';

class InventoryRepositoryImpl implements InventoryRepository {
  final InventoryRemoteDataSource remoteDataSource;

  InventoryRepositoryImpl({required this.remoteDataSource});

  @override
  Future<Result<List<Product>>> getProducts({String? category}) async {
    try {
      // In a real app, we'd pass TenantContext.current.tenantId to the datasource
      final products = await remoteDataSource.getProducts(category: category);
      return Result.success(products);
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Result<Product>> getProductBySku(String sku) async {
    try {
      final product = await remoteDataSource.getProductBySku(sku);
      return Result.success(product);
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }
}
