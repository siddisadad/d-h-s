import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:drift/drift.dart';
import 'package:flutter/foundation.dart';
import '../../domain/entities/product.dart' as product_entity;
import '../../domain/usecases/get_products.dart';
import '../../../../core/di/injection_container.dart';
import '../../../dashboard/presentation/providers/activity_provider.dart';
import '../../../dashboard/domain/entities/activity.dart' as activity_entity;
import '../../../../core/database/local_database.dart';

part 'inventory_provider.g.dart';

@riverpod
class InventoryNotifier extends _$InventoryNotifier {
  @override
  Future<List<product_entity.Product>> build() async {
    // 1. Initial load from Drift (Local Cache)
    return _fetchFromLocal();
  }

  String _currentCategory = 'All Items';
  String _searchQuery = '';

  String get currentCategory => _currentCategory;
  String get searchQuery => _searchQuery;

  Future<List<product_entity.Product>> _fetchFromLocal() async {
    final db = ref.watch(localDatabaseProvider);
    final rows = await db.select(db.products).get();

    // Trigger background sync from API
    _syncWithApi();

    if (rows.isEmpty) return [];

    final filteredRows = _currentCategory == 'All Items' 
      ? rows 
      : rows.where((r) => r.category == _currentCategory).toList();

    return filteredRows.map((row) => product_entity.Product(
      sku: row.sku,
      name: row.name,
      category: row.category,
      price: row.price,
      stock: row.stock,
      unit: row.unit,
      isLowStock: row.isLowStock,
    )).toList();
  }

  Future<void> _syncWithApi() async {
    try {
      debugPrint('🔄 [Inventory] Starting background sync...');
      final getProductsUseCase = sl.getProductsUseCase;
      final result = await getProductsUseCase(GetProductsParams(category: null));

      await result.fold(
        (failure) {
          debugPrint('❌ [Inventory] API Sync Failed: ${failure.message}');
        },
        (products) async {
          final db = ref.read(localDatabaseProvider);
          
          // Batch update local DB
          await db.batch((batch) {
            for (final p in products) {
              batch.insert(
                db.products,
                ProductsCompanion.insert(
                  sku: p.sku,
                  name: p.name,
                  category: p.category,
                  price: p.price,
                  stock: p.stock,
                  unit: p.unit,
                  isLowStock: Value(p.isLowStock),
                ),
                mode: InsertMode.insertOrReplace,
              );
            }
          });
          
          debugPrint('✅ [Inventory] API Sync Complete. Records: ${products.length}');
          // Refresh state with new local data
          ref.invalidateSelf();
        },
      );
    } catch (e) {
      debugPrint('⚠️ [Inventory] Sync Error: $e');
    }
  }

  void setCategory(String category) {
    _currentCategory = category;
    ref.invalidateSelf();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    ref.notifyListeners(); 
  }

  Future<void> adjustStock(String sku, double quantity) async {
    final db = ref.read(localDatabaseProvider);
    
    final query = db.select(db.products)..where((t) => t.sku.equals(sku));
    final productRow = await query.getSingleOrNull();
    
    if (productRow == null) return;
    
    final currentStock = double.parse(productRow.stock.replaceAll(',', ''));
    final newStock = currentStock + quantity;
    final isLow = newStock < 50;

    await (db.update(db.products)..where((t) => t.sku.equals(sku))).write(
      ProductsCompanion(
        stock: Value(newStock.toStringAsFixed(0)),
        isLowStock: Value(isLow),
      ),
    );

    // Note: In Phase 11, we should also call an API endpoint to update stock on backend
    // sl.updateStockUseCase(sku, quantity);

    ref.read(activityNotifierProvider.notifier).addActivity(
      'Stock Adjusted',
      '${productRow.name} ${quantity >= 0 ? "+" : ""}$quantity ${productRow.unit}',
      activity_entity.ActivityType.stockAdjustment,
    );

    ref.invalidateSelf();
  }
}

@riverpod
List<product_entity.Product> filteredProducts(FilteredProductsRef ref) {
  final productsAsync = ref.watch(inventoryNotifierProvider);
  final notifier = ref.watch(inventoryNotifierProvider.notifier);
  final query = notifier.searchQuery.toLowerCase();

  return productsAsync.maybeWhen(
    data: (products) {
      if (query.isEmpty) return products;
      return products.where((p) => 
        p.name.toLowerCase().contains(query) || 
        p.sku.toLowerCase().contains(query)
      ).toList();
    },
    orElse: () => [],
  );
}
