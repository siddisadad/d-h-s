import '../../domain/entities/sales_invoice.dart';

abstract class SalesRemoteDataSource {
  Future<bool> createInvoice(SalesInvoice invoice);
  Future<List<SalesInvoice>> getRecentInvoices();
}

class SalesMockDataSourceImpl implements SalesRemoteDataSource {
  @override
  Future<bool> createInvoice(SalesInvoice invoice) async {
    await Future.delayed(const Duration(seconds: 2));
    return true;
  }

  @override
  Future<List<SalesInvoice>> getRecentInvoices() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return []; // Return empty for now
  }
}
