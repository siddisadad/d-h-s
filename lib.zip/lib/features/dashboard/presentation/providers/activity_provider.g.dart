// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'activity_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$activityNotifierHash() => r'cfec4144833d4a55a969e50c0ec44ce5b769d195';

/// See also [ActivityNotifier].
@ProviderFor(ActivityNotifier)
final activityNotifierProvider = AutoDisposeAsyncNotifierProvider<
    ActivityNotifier, List<activity_entity.Activity>>.internal(
  ActivityNotifier.new,
  name: r'activityNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$activityNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ActivityNotifier
    = AutoDisposeAsyncNotifier<List<activity_entity.Activity>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
