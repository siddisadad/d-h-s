import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:deshmukh_steel_e_r_p/features/dashboard/domain/entities/activity.dart' as activity_entity;
import '../../../../core/database/local_database.dart';
import 'package:drift/drift.dart';

part 'activity_provider.g.dart';

@riverpod
class ActivityNotifier extends _$ActivityNotifier {
  @override
  Future<List<activity_entity.Activity>> build() async {
    return _loadActivities();
  }

  Future<List<activity_entity.Activity>> _loadActivities() async {
    final db = ref.watch(localDatabaseProvider);
    final rows = await (db.select(db.activities)..orderBy([(t) => OrderingTerm(expression: t.timestamp, mode: OrderingMode.desc)])).get();
    
    if (rows.isEmpty) {
      return [
        activity_entity.Activity(
          id: '1',
          title: 'System Initialized',
          subtitle: 'Deshmukh ERP is ready for business',
          timestamp: DateTime.now().subtract(const Duration(hours: 5)),
          type: activity_entity.ActivityType.userLogin,
        ),
      ];
    }

    return rows.map((row) => activity_entity.Activity(
      id: row.id,
      title: row.title,
      subtitle: row.subtitle,
      timestamp: row.timestamp,
      type: activity_entity.ActivityType.values.firstWhere((e) => e.toString() == row.type),
    )).toList();
  }

  Future<void> addActivity(String title, String subtitle, activity_entity.ActivityType type) async {
    final db = ref.read(localDatabaseProvider);
    
    await db.into(db.activities).insert(
      ActivitiesCompanion.insert(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: title,
        subtitle: subtitle,
        timestamp: DateTime.now(),
        type: type.toString(),
      ),
    );

    ref.invalidateSelf();
  }
}
