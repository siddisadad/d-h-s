import '../../domain/entities/dashboard_stats.dart';

abstract class DashboardRemoteDataSource {
  Future<DashboardStats> getStats();
  Future<List<double>> getRevenueTrend();
}

class DashboardMockDataSourceImpl implements DashboardRemoteDataSource {
  @override
  Future<DashboardStats> getStats() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return DashboardStats(
      sales: '₹1,45,200',
      purchases: '₹82,400',
      collections: '₹92,000',
      lowStock: '14 Items',
    );
  }

  @override
  Future<List<double>> getRevenueTrend() async {
    return [45.0, 52.0, 48.0, 70.0, 61.0, 85.0, 92.0];
  }
}
