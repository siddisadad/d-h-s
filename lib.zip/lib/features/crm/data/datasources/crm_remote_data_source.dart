import '../../domain/entities/contact.dart';
import '../../domain/entities/ledger_entry.dart';

abstract class CrmRemoteDataSource {
  Future<List<Contact>> getContacts(ContactType type);
  Future<List<LedgerEntry>> getLedgerByContactId(String contactId);
}

class CrmMockDataSourceImpl implements CrmRemoteDataSource {
  @override
  Future<List<Contact>> getContacts(ContactType type) async {
    await Future.delayed(const Duration(milliseconds: 300));
    if (type == ContactType.supplier) {
      return [
        Contact(
          id: 'S1',
          name: 'Adarsh Steel Industries',
          initials: 'AS',
          contact: '+91 98765 43210',
          gstin: '27AAACA1234A1Z5',
          balance: '₹4,50,000',
          location: 'Industrial Area, Pune',
          type: ContactType.supplier,
        ),
        Contact(
          id: 'S2',
          name: 'Mahadev Khatape Steel',
          initials: 'MK',
          contact: '+91 88888 77777',
          gstin: '27BBBCB5678B2Z1',
          balance: '₹1,25,500',
          location: 'Loni Kalbhor',
          type: ContactType.supplier,
        ),
      ];
    } else {
      return [
        Contact(
          id: 'C1',
          name: 'Rohan Construction',
          initials: 'RC',
          contact: '+91 98765 43210',
          gstin: '27AAACA1234A1Z5',
          balance: '₹45,820',
          location: 'MIDC Area, Pune',
          type: ContactType.customer,
        ),
      ];
    }
  }

  @override
  Future<List<LedgerEntry>> getLedgerByContactId(String contactId) async {
    await Future.delayed(const Duration(milliseconds: 400));
    return [
      LedgerEntry(
        amount: '12,400',
        balance: '45,820',
        date: '22 May 2024',
        ref: '#SI-2024-882',
        type: 'Sales Invoice',
        isDebit: true,
      ),
      LedgerEntry(
        amount: '5,000',
        balance: '33,420',
        date: '18 May 2024',
        ref: '#PAY-9912',
        type: 'Payment Received',
        isDebit: false,
      ),
    ];
  }
}
