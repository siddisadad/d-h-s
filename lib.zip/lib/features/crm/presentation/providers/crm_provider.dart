import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/entities/contact.dart';
import '../../../../core/di/injection_container.dart';

part 'crm_provider.g.dart';

@riverpod
class CrmNotifier extends _$CrmNotifier {
  @override
  Future<List<Contact>> build(ContactType type) async {
    return _fetchContacts(type);
  }

  Future<List<Contact>> _fetchContacts(ContactType type) async {
    final getContactsUseCase = sl.getContactsUseCase;
    final result = await getContactsUseCase(type);
    
    return result.fold(
      (failure) => throw Exception(failure.message),
      (list) => list,
    );
  }

  Future<void> refresh(ContactType type) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _fetchContacts(type));
  }
}
