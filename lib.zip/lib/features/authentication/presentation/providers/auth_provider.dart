import 'package:flutter/foundation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/entities/app_user.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../data/repositories/auth_repository_impl.dart';

part 'auth_provider.g.dart';

@riverpod
AuthRepository authRepository(AuthRepositoryRef ref) {
  return AuthRepositoryImpl();
}

@Riverpod(keepAlive: true)
class Auth extends _$Auth {
  @override
  AppUser? build() {
    return null; // Initial state: not logged in
  }

  Future<void> login(String email, String password) async {
    debugPrint('🔑 Attempting login for: $email');
    final repo = ref.read(authRepositoryProvider);
    final user = await repo.login(email, password);
    
    if (user != null) {
      debugPrint('✅ Login successful for: ${user.displayName}');
      state = user;
    } else {
      debugPrint('❌ Login failed: Invalid credentials');
      throw Exception('Invalid credentials');
    }
  }

  void logout() {
    ref.read(authRepositoryProvider).logout();
    state = null;
  }

  Future<void> sendPasswordResetEmail(String email) async {
    if (email.isEmpty || !email.contains('@')) {
      throw Exception('Please enter a valid email address');
    }
    
    await ref.read(authRepositoryProvider).resetPassword(email);
  }
}
