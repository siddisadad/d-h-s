import 'package:flutter/foundation.dart';
import '../../domain/entities/app_user.dart';
import '../../domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  @override
  Future<AppUser?> login(String email, String password) async {
    debugPrint('MockAuthRepo: login attempt with $email');
    // Mock login - allow any email with 'admin' or the specific one
    if ((email == 'admin@dhs.com' && password == 'password') || email == 'admin') {
      return AppUser(id: '1', email: email, displayName: 'Admin User', role: 'Admin');
    }
    return null;
  }

  @override
  Future<void> logout() async {
    // Mock logout
  }

  @override
  Future<void> resetPassword(String email) async {
    // Mock reset password
    await Future.delayed(const Duration(seconds: 1));
  }
}
