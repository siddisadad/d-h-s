import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/entities/purchase_order.dart';
import '../../../../core/di/injection_container.dart';

part 'purchase_provider.g.dart';

@riverpod
class PurchaseNotifier extends _$PurchaseNotifier {
  @override
  Future<List<PurchaseOrder>> build() async {
    return _fetchPurchases();
  }

  Future<List<PurchaseOrder>> _fetchPurchases() async {
    final repository = sl.purchaseRepository;
    final result = await repository.getRecentPurchases();
    return result.fold(
      (failure) => throw Exception(failure.message),
      (purchases) => purchases,
    );
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _fetchPurchases());
  }
}
