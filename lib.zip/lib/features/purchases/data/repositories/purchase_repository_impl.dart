import 'package:deshmukh_steel_e_r_p/core/error/failures.dart';
import 'package:deshmukh_steel_e_r_p/core/error/result.dart';
import 'package:deshmukh_steel_e_r_p/features/purchases/domain/entities/purchase_order.dart';
import 'package:deshmukh_steel_e_r_p/features/purchases/domain/repositories/purchase_repository.dart';

class PurchaseRepositoryImpl implements PurchaseRepository {
  @override
  Future<Result<List<PurchaseOrder>>> getRecentPurchases() async {
    try {
      await Future.delayed(const Duration(milliseconds: 500));
      return Result.success([
        PurchaseOrder(id: 'TSL-2024-01', supplierName: 'Tata Steel Ltd.', date: '24 Oct', amount: '₹1,25,000', status: 'received'),
        PurchaseOrder(id: 'JSW-HRD-88', supplierName: 'JSW Steel Corp', date: '23 Oct', amount: '₹84,200', status: 'Pending'),
      ]);
    } catch (e) {
      return Result.error(ServerFailure(e.toString()));
    }
  }
}
