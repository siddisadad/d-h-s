import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'step_indicator_model.dart';
export 'step_indicator_model.dart';

class StepIndicatorWidget extends StatefulWidget {
  const StepIndicatorWidget({
    super.key,
    String? label,
    String? number,
    bool? active,
  })  : this.label = label ?? 'Customer',
        this.number = number ?? '1',
        this.active = active ?? true;

  final String label;
  final String number;
  final bool active;

  @override
  State<StepIndicatorWidget> createState() => _StepIndicatorWidgetState();
}

class _StepIndicatorWidgetState extends State<StepIndicatorWidget> {
  late StepIndicatorModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => StepIndicatorModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 24.0,
          height: 24.0,
          decoration: BoxDecoration(
            color: valueOrDefault<Color>(
              valueOrDefault<bool>(
                widget.active,
                true,
              )
                  ? context.colorScheme.primary
                  : context.colorScheme.surface,
              context.colorScheme.primary,
            ),
            borderRadius: BorderRadius.circular(9999.0),
            shape: BoxShape.rectangle,
            border: Border.all(
              color: valueOrDefault<Color>(
                valueOrDefault<bool>(
                  widget.active,
                  true,
                )
                    ? context.colorScheme.primary
                    : context.colorScheme.outline,
                context.colorScheme.primary,
              ),
              width: 1.0,
            ),
          ),
          alignment: AlignmentDirectional(0.0, 0.0),
          child: Text(
            valueOrDefault<String>(
              widget.number,
              '1',
            ),
            style: context.textTheme.labelSmall!.override(
                  font: GoogleFonts.inter(
                    fontWeight: FontWeight.bold,
                    fontStyle:
                        context.textTheme.labelSmall!.fontStyle,
                  ),
                  color: valueOrDefault<Color>(
                    valueOrDefault<bool>(
                      widget.active,
                      true,
                    )
                        ? context.colorScheme.onPrimary
                        : context.textTheme.bodySmall!.color,
                    context.colorScheme.onPrimary,
                  ),
                  letterSpacing: 0.0,
                  fontWeight: FontWeight.bold,
                  fontStyle: context.textTheme.labelSmall!.fontStyle,
                  lineHeight: 1.45,
                ),
          ),
        ),
        Text(
          valueOrDefault<String>(
            widget.label,
            'Customer',
          ),
          style: context.textTheme.labelSmall!.override(
                font: GoogleFonts.inter(
                  fontWeight:
                      context.textTheme.labelSmall!.fontWeight,
                  fontStyle: context.textTheme.labelSmall!.fontStyle,
                ),
                color: valueOrDefault<Color>(
                  valueOrDefault<bool>(
                    widget.active,
                    true,
                  )
                      ? context.colorScheme.onSurface
                      : context.textTheme.bodySmall!.color,
                  context.colorScheme.onSurface,
                ),
                letterSpacing: 0.0,
                fontWeight: context.textTheme.labelSmall!.fontWeight,
                fontStyle: context.textTheme.labelSmall!.fontStyle,
                lineHeight: 1.45,
              ),
        ),
      ].divide(SizedBox(width: context.tokens.space8)),
    );
  }
}
