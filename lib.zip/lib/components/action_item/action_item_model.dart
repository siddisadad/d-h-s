import '../../core/utils/extensions.dart';
import 'action_item_widget.dart' show ActionItemWidget;
import 'package:flutter/material.dart';

class ActionItemModel extends FlutterFlowModel<ActionItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
