import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'ledger_stat_model.dart';
export 'ledger_stat_model.dart';

class LedgerStatWidget extends StatefulWidget {
  const LedgerStatWidget({
    super.key,
    String? label,
    Color? tone,
    String? value,
  })  : this.label = label ?? 'Outstanding',
        this.tone = tone ?? const Color(0x00000000),
        this.value = value ?? '₹45,820';

  final String label;
  final Color tone;
  final String value;

  @override
  State<LedgerStatWidget> createState() => _LedgerStatWidgetState();
}

class _LedgerStatWidgetState extends State<LedgerStatWidget> {
  late LedgerStatModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LedgerStatModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tokens = context.tokens;

    return Container(
      decoration: BoxDecoration(
        color: context.colorScheme.surface,
        borderRadius: BorderRadius.circular(tokens.radiusLg),
        shape: BoxShape.rectangle,
        border: Border.all(
          color: context.colorScheme.outline,
          width: 1.0,
        ),
        boxShadow: [tokens.shadowSm],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.label,
              style: context.textTheme.labelSmall!.copyWith(
                color: context.textTheme.bodySmall!.color,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              widget.value,
              style: context.textTheme.headlineSmall!.copyWith(
                fontWeight: FontWeight.bold,
                color: widget.tone != const Color(0x00000000) ? widget.tone : context.colorScheme.onSurface,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
