import '../../core/utils/extensions.dart';
import 'ledger_stat_widget.dart' show LedgerStatWidget;
import 'package:flutter/material.dart';

class LedgerStatModel extends FlutterFlowModel<LedgerStatWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
