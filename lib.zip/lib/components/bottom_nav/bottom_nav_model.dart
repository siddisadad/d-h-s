import '../../core/utils/extensions.dart';
import 'bottom_nav_widget.dart' show BottomNavWidget;
import 'package:flutter/material.dart';

class BottomNavModel extends FlutterFlowModel<BottomNavWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
