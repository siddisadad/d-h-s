import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'button_model.dart';
export 'button_model.dart';

class ButtonWidget extends StatefulWidget {
  const ButtonWidget({
    super.key,
    this.icon,
    bool? iconPresent,
    this.iconEnd,
    bool? iconEndPresent,
    String? content,
    String? variant,
    String? size,
    bool? fullWidth,
    bool? loading,
    bool? disabled,
    this.onPressed,
  })  : this.iconPresent = iconPresent ?? false,
        this.iconEndPresent = iconEndPresent ?? false,
        this.content = content ?? 'Login to Dashboard',
        this.variant = variant ?? 'primary',
        this.size = size ?? 'large',
        this.fullWidth = fullWidth ?? true,
        this.loading = loading ?? false,
        this.disabled = disabled ?? false;

  final Widget? icon;
  final bool iconPresent;
  final Widget? iconEnd;
  final bool iconEndPresent;
  final String content;
  final String variant;
  final String size;
  final bool fullWidth;
  final bool loading;
  final bool disabled;
  final VoidCallback? onPressed;

  @override
  State<ButtonWidget> createState() => _ButtonWidgetState();
}

class _ButtonWidgetState extends State<ButtonWidget> {
  late ButtonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ButtonModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: valueOrDefault<double>(
        valueOrDefault<bool>(
          widget.disabled,
          false,
        )
            ? 0.55
            : 1.0,
        1.0,
      ),
      child: Container(
        decoration: BoxDecoration(
          color: valueOrDefault<Color>(
            () {
              if (valueOrDefault<String>(
                    widget.variant,
                    'primary',
                  ) ==
                  'secondary') {
                return context.colorScheme.secondary;
              } else if (valueOrDefault<String>(
                    widget.variant,
                    'primary',
                  ) ==
                  'outline') {
                return Colors.transparent;
              } else if (valueOrDefault<String>(
                    widget.variant,
                    'primary',
                  ) ==
                  'ghost') {
                return Colors.transparent;
              } else if (valueOrDefault<String>(
                    widget.variant,
                    'primary',
                  ) ==
                  'destructive') {
                return context.colorScheme.error;
              } else {
                return context.colorScheme.primary;
              }
            }(),
            context.colorScheme.primary,
          ),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(valueOrDefault<double>(
              () {
                if (valueOrDefault<String>(
                      widget.size,
                      'large',
                    ) ==
                    'small') {
                  return 8.0;
                } else if (valueOrDefault<String>(
                      widget.size,
                      'large',
                    ) ==
                    'large') {
                  return 16.0;
                } else {
                  return 12.0;
                }
              }(),
              16.0,
            )),
            topRight: Radius.circular(valueOrDefault<double>(
              () {
                if (valueOrDefault<String>(
                      widget.size,
                      'large',
                    ) ==
                    'small') {
                  return 8.0;
                } else if (valueOrDefault<String>(
                      widget.size,
                      'large',
                    ) ==
                    'large') {
                  return 16.0;
                } else {
                  return 12.0;
                }
              }(),
              16.0,
            )),
            bottomLeft: Radius.circular(valueOrDefault<double>(
              () {
                if (valueOrDefault<String>(
                      widget.size,
                      'large',
                    ) ==
                    'small') {
                  return 8.0;
                } else if (valueOrDefault<String>(
                      widget.size,
                      'large',
                    ) ==
                    'large') {
                  return 16.0;
                } else {
                  return 12.0;
                }
              }(),
              16.0,
            )),
            bottomRight: Radius.circular(valueOrDefault<double>(
              () {
                if (valueOrDefault<String>(
                      widget.size,
                      'large',
                    ) ==
                    'small') {
                  return 8.0;
                } else if (valueOrDefault<String>(
                      widget.size,
                      'large',
                    ) ==
                    'large') {
                  return 16.0;
                } else {
                  return 12.0;
                }
              }(),
              16.0,
            )),
          ),
          shape: BoxShape.rectangle,
          border: Border.all(
            color: valueOrDefault<Color>(
              valueOrDefault<String>(
                        widget.variant,
                        'primary',
                      ) ==
                      'outline'
                  ? context.colorScheme.outline
                  : Colors.transparent,
              Colors.transparent,
            ),
            width: valueOrDefault<double>(
              valueOrDefault<String>(
                        widget.variant,
                        'primary',
                      ) ==
                      'outline'
                  ? 1.0
                  : 0.0,
              0.0,
            ),
          ),
        ),
        child: InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            if (!widget.disabled && !widget.loading) {
              widget.onPressed?.call();
            }
          },
          child: Stack(
            alignment: AlignmentDirectional(0.0, 0.0),
            children: [
              Opacity(
                opacity: valueOrDefault<double>(
                  valueOrDefault<bool>(
                    widget.loading,
                    false,
                  )
                      ? 0.0
                      : 1.0,
                  1.0,
                ),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(
                      valueOrDefault<double>(
                        () {
                          if (valueOrDefault<String>(
                                widget.size,
                                'large',
                              ) ==
                              'small') {
                            return 16.0;
                          } else if (valueOrDefault<String>(
                                widget.size,
                                'large',
                              ) ==
                              'large') {
                            return 32.0;
                          } else {
                            return 24.0;
                          }
                        }(),
                        32.0,
                      ),
                      valueOrDefault<double>(
                        () {
                          if (valueOrDefault<String>(
                                widget.size,
                                'large',
                              ) ==
                              'small') {
                            return 4.0;
                          } else if (valueOrDefault<String>(
                                widget.size,
                                'large',
                              ) ==
                              'large') {
                            return 16.0;
                          } else {
                            return 8.0;
                          }
                        }(),
                        16.0,
                      ),
                      valueOrDefault<double>(
                        () {
                          if (valueOrDefault<String>(
                                widget.size,
                                'large',
                              ) ==
                              'small') {
                            return 16.0;
                          } else if (valueOrDefault<String>(
                                widget.size,
                                'large',
                              ) ==
                              'large') {
                            return 32.0;
                          } else {
                            return 24.0;
                          }
                        }(),
                        32.0,
                      ),
                      valueOrDefault<double>(
                        () {
                          if (valueOrDefault<String>(
                                widget.size,
                                'large',
                              ) ==
                              'small') {
                            return 4.0;
                          } else if (valueOrDefault<String>(
                                widget.size,
                                'large',
                              ) ==
                              'large') {
                            return 16.0;
                          } else {
                            return 8.0;
                          }
                        }(),
                        16.0,
                      )),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      if (valueOrDefault<bool>(
                        widget.iconPresent,
                        false,
                      ))
                        widget.icon!,
                      Text(
                        valueOrDefault<String>(
                          widget.content,
                          'Login to Dashboard',
                        ),
                        maxLines: 1,
                        style: context.textTheme.labelMedium!.override(
                              font: GoogleFonts.inter(
                                fontWeight: context.textTheme
                                    .labelMedium!
                                    .fontWeight,
                                fontStyle: context.textTheme
                                    .labelMedium!
                                    .fontStyle,
                              ),
                              color: valueOrDefault<Color>(
                                () {
                                  if (valueOrDefault<String>(
                                        widget.variant,
                                        'primary',
                                      ) ==
                                      'secondary') {
                                    return context.colorScheme
                                        .onSecondary;
                                  } else if (valueOrDefault<String>(
                                        widget.variant,
                                        'primary',
                                      ) ==
                                      'outline') {
                                    return context.colorScheme
                                        .onSurface;
                                  } else if (valueOrDefault<String>(
                                        widget.variant,
                                        'primary',
                                      ) ==
                                      'ghost') {
                                    return context.colorScheme.primary;
                                  } else if (valueOrDefault<String>(
                                        widget.variant,
                                        'primary',
                                      ) ==
                                      'destructive') {
                                    return context.colorScheme.onError;
                                  } else {
                                    return context.colorScheme.onPrimary;
                                  }
                                }(),
                                context.colorScheme.onPrimary,
                              ),
                              letterSpacing: 0.0,
                              fontWeight: context.textTheme
                                  .labelMedium!
                                  .fontWeight,
                              fontStyle: context.textTheme
                                  .labelMedium!
                                  .fontStyle,
                              lineHeight: 1.33,
                            ),
                        overflow: TextOverflow.clip,
                      ),
                      if (valueOrDefault<bool>(
                        widget.iconEndPresent,
                        false,
                      ))
                        widget.iconEnd!,
                    ].divide(SizedBox(width: context.tokens.space8)),
                  ),
                ),
              ),
              if (valueOrDefault<bool>(
                widget.loading,
                false,
              ))
                SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.0,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      valueOrDefault<Color>(
                        () {
                          if (valueOrDefault<String>(
                                widget.variant,
                                'primary',
                              ) ==
                              'secondary') {
                            return context.colorScheme.onSecondary;
                          } else if (valueOrDefault<String>(
                                widget.variant,
                                'primary',
                              ) ==
                              'outline') {
                            return context.colorScheme.onSurface;
                          } else if (valueOrDefault<String>(
                                widget.variant,
                                'primary',
                              ) ==
                              'ghost') {
                            return context.colorScheme.primary;
                          } else if (valueOrDefault<String>(
                                widget.variant,
                                'primary',
                              ) ==
                              'destructive') {
                            return context.colorScheme.error;
                          } else {
                            return context.colorScheme.onPrimary;
                          }
                        }(),
                        context.colorScheme.onPrimary,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
