import '../../core/utils/extensions.dart';
import 'button_widget.dart' show ButtonWidget;
import 'package:flutter/material.dart';

class ButtonModel extends FlutterFlowModel<ButtonWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
