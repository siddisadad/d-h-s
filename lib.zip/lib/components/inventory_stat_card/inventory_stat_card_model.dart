import '../../core/utils/extensions.dart';
import 'inventory_stat_card_widget.dart' show InventoryStatCardWidget;
import 'package:flutter/material.dart';

class InventoryStatCardModel extends FlutterFlowModel<InventoryStatCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
