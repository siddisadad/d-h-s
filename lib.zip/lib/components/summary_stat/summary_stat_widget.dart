import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'summary_stat_model.dart';
export 'summary_stat_model.dart';

class SummaryStatWidget extends StatefulWidget {
  const SummaryStatWidget({
    super.key,
    Color? color,
    String? label,
    String? value,
  })  : this.color = color ?? const Color(0x00000000),
        this.label = label ?? 'Total Income',
        this.value = value ?? '₹ 4.2L';

  final Color color;
  final String label;
  final String value;

  @override
  State<SummaryStatWidget> createState() => _SummaryStatWidgetState();
}

class _SummaryStatWidgetState extends State<SummaryStatWidget> {
  late SummaryStatModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SummaryStatModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: context.colorScheme.surface,
        borderRadius: BorderRadius.circular(16.0),
        shape: BoxShape.rectangle,
        border: Border.all(
          color: context.colorScheme.outline,
          width: 1.0,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Container(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                valueOrDefault<String>(
                  widget.label,
                  'Total Income',
                ),
                style: context.textTheme.labelSmall!.override(
                      font: GoogleFonts.inter(
                        fontWeight:
                            context.textTheme.labelSmall!.fontWeight,
                        fontStyle:
                            context.textTheme.labelSmall!.fontStyle,
                      ),
                      color: context.textTheme.bodySmall!.color,
                      letterSpacing: 0.0,
                      fontWeight:
                          context.textTheme.labelSmall!.fontWeight,
                      fontStyle:
                          context.textTheme.labelSmall!.fontStyle,
                      lineHeight: 1.45,
                    ),
              ),
              Text(
                valueOrDefault<String>(
                  widget.value,
                  '₹ 4.2L',
                ),
                style: context.textTheme.titleMedium!.override(
                      font: GoogleFonts.plusJakartaSans(
                        fontWeight: FontWeight.bold,
                        fontStyle:
                            context.textTheme.titleMedium!.fontStyle,
                      ),
                      color: valueOrDefault<Color>(
                        widget.color,
                        AppColors.success,
                      ),
                      letterSpacing: 0.0,
                      fontWeight: FontWeight.bold,
                      fontStyle:
                          context.textTheme.titleMedium!.fontStyle,
                      lineHeight: 1.5,
                    ),
              ),
            ].divide(SizedBox(height: context.tokens.space4)),
          ),
        ),
      ),
    );
  }
}
