import '../../core/utils/extensions.dart';
import 'settings_group_widget.dart' show SettingsGroupWidget;
import 'package:flutter/material.dart';

class SettingsGroupModel extends FlutterFlowModel<SettingsGroupWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
