import '../../core/utils/extensions.dart';
import 'product_list_item_widget.dart' show ProductListItemWidget;
import 'package:flutter/material.dart';

class ProductListItemModel extends FlutterFlowModel<ProductListItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
