import '../../core/design_system/theme/app_theme.dart';
import '../../core/widgets/custom_card.dart';
import 'package:flutter/material.dart';

class ProductListItemWidget extends StatelessWidget {
  final String category;
  final String name;
  final String price;
  final String sku;
  final String stock;
  final String unit;
  final bool lowStock;

  const ProductListItemWidget({
    super.key,
    required this.category,
    required this.name,
    required this.price,
    required this.sku,
    required this.stock,
    required this.unit,
    required this.lowStock,
  });

  @override
  Widget build(BuildContext context) {
    final tokens = context.tokens;
    
    return CustomCard(
      padding: EdgeInsets.all(tokens.space16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: context.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      'SKU: $sku',
                      style: context.textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: (lowStock ? AppColors.error : AppColors.success).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(tokens.radiusFull),
                ),
                child: Text(
                  lowStock ? 'Low Stock' : 'In Stock',
                  style: context.textTheme.labelSmall?.copyWith(
                    color: lowStock ? AppColors.error : AppColors.success,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          Divider(height: 24, color: context.theme.dividerColor.withValues(alpha: 0.5)),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildDetail(context, 'CATEGORY', category),
              _buildDetail(context, 'UNIT', unit),
              _buildDetail(context, 'PRICE', price, isPrimary: true),
              _buildDetail(context, 'STOCK', '$stock $unit', isBold: true, color: lowStock ? AppColors.error : AppColors.primary),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDetail(BuildContext context, String label, String value, {bool isPrimary = false, bool isBold = false, Color? color}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: context.textTheme.labelSmall?.copyWith(fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.0),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: context.textTheme.bodyMedium?.copyWith(
            fontWeight: isBold || isPrimary ? FontWeight.w700 : FontWeight.w500,
            color: color ?? (isPrimary ? AppColors.primary : AppColors.textPrimary),
          ),
        ),
      ],
    );
  }
}
