import '../../core/utils/extensions.dart';
import 'transaction_item_widget.dart' show TransactionItemWidget;
import 'package:flutter/material.dart';

class TransactionItemModel extends FlutterFlowModel<TransactionItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
