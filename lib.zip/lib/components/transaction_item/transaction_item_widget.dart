import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'transaction_item_model.dart';
export 'transaction_item_model.dart';

class TransactionItemWidget extends StatefulWidget {
  const TransactionItemWidget({
    super.key,
    String? amount,
    String? balance,
    String? date,
    String? ref,
    String? type,
    bool? isDebit,
  })  : this.amount = amount ?? '12,400',
        this.balance = balance ?? '45,820',
        this.date = date ?? '22 May 2024',
        this.ref = ref ?? '#SI-2024-882',
        this.type = type ?? 'Sales Invoice',
        this.isDebit = isDebit ?? true;

  final String amount;
  final String balance;
  final String date;
  final String ref;
  final String type;
  final bool isDebit;

  @override
  State<TransactionItemWidget> createState() => _TransactionItemWidgetState();
}

class _TransactionItemWidgetState extends State<TransactionItemWidget> {
  late TransactionItemModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TransactionItemModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: context.colorScheme.surface,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 44.0,
                  height: 44.0,
                  decoration: BoxDecoration(
                    color: widget.isDebit ? context.colorScheme.error.withValues(alpha: 0.1) : AppColors.success.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(context.tokens.radiusMd),
                  ),
                  child: Icon(
                    widget.isDebit ? Icons.description_rounded : Icons.payments_rounded,
                    color: widget.isDebit ? context.colorScheme.error : AppColors.success,
                    size: 20.0,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.type,
                        style: context.textTheme.bodyMedium!.copyWith(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${widget.ref} • ${widget.date}',
                        style: context.textTheme.labelSmall!.copyWith(color: context.textTheme.bodySmall!.color),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '₹${widget.amount}',
                      style: context.textTheme.titleSmall!.copyWith(
                        color: widget.isDebit ? context.colorScheme.error : AppColors.success,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Bal: ₹${widget.balance}',
                      style: context.textTheme.labelSmall!.copyWith(color: context.textTheme.bodySmall!.color, fontSize: 10),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Divider(height: 1, thickness: 1, color: context.colorScheme.outline, indent: 76),
        ],
      ),
    );
  }
}
