import '../../core/utils/extensions.dart';
import 'report_category_card_widget.dart' show ReportCategoryCardWidget;
import 'package:flutter/material.dart';

class ReportCategoryCardModel
    extends FlutterFlowModel<ReportCategoryCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
