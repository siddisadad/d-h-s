import '../../core/utils/extensions.dart';
import 'purchase_stat_card_widget.dart' show PurchaseStatCardWidget;
import 'package:flutter/material.dart';

class PurchaseStatCardModel extends FlutterFlowModel<PurchaseStatCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
