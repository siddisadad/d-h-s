import '/components/button/button_widget.dart';
import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'supplier_list_item_model.dart';
export 'supplier_list_item_model.dart';

class SupplierListItemWidget extends StatefulWidget {
  const SupplierListItemWidget({
    super.key,
    String? balance,
    String? contact,
    String? gstin,
    String? initials,
    String? name,
  })  : this.balance = balance ?? '₹4,50,000',
        this.contact = contact ?? '+91 98765 43210',
        this.gstin = gstin ?? '27AAACA1234A1Z5',
        this.initials = initials ?? 'AS',
        this.name = name ?? 'Adarsh Steel Industries';

  final String balance;
  final String contact;
  final String gstin;
  final String initials;
  final String name;

  @override
  State<SupplierListItemWidget> createState() => _SupplierListItemWidgetState();
}

class _SupplierListItemWidgetState extends State<SupplierListItemWidget> {
  late SupplierListItemModel _model;
  bool _isLedgerLoading = false;
  bool _isPayableLoading = false;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SupplierListItemModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tokens = context.tokens;

    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Container(
        decoration: BoxDecoration(
          color: context.colorScheme.surface,
          borderRadius: BorderRadius.circular(tokens.radiusLg),
          shape: BoxShape.rectangle,
          border: Border.all(
            color: context.colorScheme.outline,
            width: 1.0,
          ),
          boxShadow: [tokens.shadowSm],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: 52.0,
                    height: 52.0,
                    decoration: BoxDecoration(
                      color: context.colorScheme.primaryContainer,
                      shape: BoxShape.circle,
                    ),
                    alignment: const AlignmentDirectional(0.0, 0.0),
                    child: Text(
                      widget.initials,
                      textAlign: TextAlign.center,
                      style: context.textTheme.titleMedium!.copyWith(
                        color: context.colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: context.textTheme.titleMedium!.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'GSTIN: ${widget.gstin}',
                          style: context.textTheme.labelSmall!.copyWith(
                            color: context.textTheme.bodySmall!.color,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.success.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(tokens.radiusFull),
                    ),
                    child: Text(
                      'Active',
                      style: context.textTheme.labelSmall!.copyWith(
                        color: AppColors.success,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12.0),
                child: Divider(height: 1, thickness: 1),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Outstanding',
                        style: context.textTheme.labelSmall!.copyWith(color: context.textTheme.bodySmall!.color),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        widget.balance,
                        style: context.textTheme.titleMedium!.copyWith(
                          color: context.colorScheme.error,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Contact',
                        style: context.textTheme.labelSmall!.copyWith(color: context.textTheme.bodySmall!.color),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        widget.contact,
                        style: context.textTheme.bodyMedium!.copyWith(fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: wrapWithModel(
                      model: _model.buttonModel1,
                      updateCallback: () => safeSetState(() {}),
                      child: ButtonWidget(
                        icon: Icon(
                          Icons.account_balance_wallet_rounded,
                          color: context.colorScheme.onSurface,
                          size: 20.0,
                        ),
                        iconPresent: true,
                        iconEndPresent: false,
                        content: 'Ledger',
                        variant: 'outline',
                        size: 'small',
                        fullWidth: true,
                        loading: _isLedgerLoading,
                        onPressed: () async {
                          safeSetState(() => _isLedgerLoading = true);
                          await Future.delayed(const Duration(seconds: 1));
                          if (mounted) {
                            safeSetState(() => _isLedgerLoading = false);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Opening Ledger for ${widget.name}...')),
                            );
                          }
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: wrapWithModel(
                      model: _model.buttonModel2,
                      updateCallback: () => safeSetState(() {}),
                      child: ButtonWidget(
                        icon: const Icon(
                          Icons.payments_rounded,
                          color: Colors.white,
                          size: 20.0,
                        ),
                        iconPresent: true,
                        iconEndPresent: false,
                        content: 'Payable',
                        variant: 'primary',
                        size: 'small',
                        fullWidth: true,
                        loading: _isPayableLoading,
                        onPressed: () async {
                          safeSetState(() => _isPayableLoading = true);
                          await Future.delayed(const Duration(seconds: 1));
                          if (mounted) {
                            safeSetState(() => _isPayableLoading = false);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Processing Payable for ${widget.name}...')),
                            );
                          }
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
