import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'switch_component_model.dart';
export 'switch_component_model.dart';

class SwitchComponentWidget extends StatefulWidget {
  const SwitchComponentWidget({
    super.key,
    String? label,
    bool? labelPresent,
    String? variant,
    bool? active,
  })  : this.label = label ?? 'Remember Me',
        this.labelPresent = labelPresent ?? true,
        this.variant = variant ?? 'Android',
        this.active = active ?? true;

  final String label;
  final bool labelPresent;
  final String variant;
  final bool active;

  @override
  State<SwitchComponentWidget> createState() => _SwitchComponentWidgetState();
}

class _SwitchComponentWidgetState extends State<SwitchComponentWidget> {
  late SwitchComponentModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SwitchComponentModel());

    _model.switchValue = valueOrDefault<bool>(
      valueOrDefault<bool>(
        widget.active,
        true,
      )
          ? true
          : false,
      true,
    );
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 8.0),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (valueOrDefault<bool>(
            () {
              if (valueOrDefault<String>(
                    widget.variant,
                    'Android',
                  ) ==
                  'iOS') {
                return true;
              } else if (valueOrDefault<String>(
                    widget.variant,
                    'Android',
                  ) ==
                  'iOS 26+') {
                return false;
              } else {
                return true;
              }
            }(),
            true,
          ))
            Switch(
              value: _model.switchValue!,
              onChanged: (newValue) async {
                safeSetState(() => _model.switchValue = newValue);
              },
              activeTrackColor: context.colorScheme.primary,
              inactiveTrackColor: context.colorScheme.outline,
              inactiveThumbColor: context.textTheme.bodySmall!.color,
            ),
          if (valueOrDefault<bool>(
            () {
              if (valueOrDefault<String>(
                    widget.variant,
                    'Android',
                  ) ==
                  'iOS') {
                return false;
              } else if (valueOrDefault<String>(
                    widget.variant,
                    'Android',
                  ) ==
                  'iOS 26+') {
                return true;
              } else {
                return false;
              }
            }(),
            false,
          ))
            Container(
              width: valueOrDefault<double>(
                valueOrDefault<String>(
                          widget.variant,
                          'Android',
                        ) ==
                        'iOS 26+'
                    ? 64.0
                    : 56.0,
                56.0,
              ),
              height: valueOrDefault<double>(
                valueOrDefault<String>(
                          widget.variant,
                          'Android',
                        ) ==
                        'iOS 26+'
                    ? 28.0
                    : 32.0,
                32.0,
              ),
              decoration: BoxDecoration(
                color: valueOrDefault<Color>(
                  valueOrDefault<bool>(
                    widget.active,
                    true,
                  )
                      ? context.colorScheme.primary
                      : context.colorScheme.outline,
                  context.colorScheme.primary,
                ),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(valueOrDefault<double>(
                    valueOrDefault<String>(
                              widget.variant,
                              'Android',
                            ) ==
                            'iOS 26+'
                        ? 9999.0
                        : 16.0,
                    16.0,
                  )),
                  topRight: Radius.circular(valueOrDefault<double>(
                    valueOrDefault<String>(
                              widget.variant,
                              'Android',
                            ) ==
                            'iOS 26+'
                        ? 9999.0
                        : 16.0,
                    16.0,
                  )),
                  bottomLeft: Radius.circular(valueOrDefault<double>(
                    valueOrDefault<String>(
                              widget.variant,
                              'Android',
                            ) ==
                            'iOS 26+'
                        ? 9999.0
                        : 16.0,
                    16.0,
                  )),
                  bottomRight: Radius.circular(valueOrDefault<double>(
                    valueOrDefault<String>(
                              widget.variant,
                              'Android',
                            ) ==
                            'iOS 26+'
                        ? 9999.0
                        : 16.0,
                    16.0,
                  )),
                ),
                shape: BoxShape.rectangle,
              ),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(
                    valueOrDefault<double>(
                      valueOrDefault<String>(
                                widget.variant,
                                'Android',
                              ) ==
                              'iOS 26+'
                          ? 2.0
                          : 3.0,
                      3.0,
                    ),
                    valueOrDefault<double>(
                      valueOrDefault<String>(
                                widget.variant,
                                'Android',
                              ) ==
                              'iOS 26+'
                          ? 2.0
                          : 3.0,
                      3.0,
                    ),
                    valueOrDefault<double>(
                      valueOrDefault<String>(
                                widget.variant,
                                'Android',
                              ) ==
                              'iOS 26+'
                          ? 2.0
                          : 3.0,
                      3.0,
                    ),
                    valueOrDefault<double>(
                      valueOrDefault<String>(
                                widget.variant,
                                'Android',
                              ) ==
                              'iOS 26+'
                          ? 2.0
                          : 3.0,
                      3.0,
                    )),
                child: Container(
                  child: Container(
                    width: valueOrDefault<double>(
                      valueOrDefault<String>(
                                widget.variant,
                                'Android',
                              ) ==
                              'iOS 26+'
                          ? 39.0
                          : 26.0,
                      26.0,
                    ),
                    height: valueOrDefault<double>(
                      valueOrDefault<String>(
                                widget.variant,
                                'Android',
                              ) ==
                              'iOS 26+'
                          ? 24.0
                          : 26.0,
                      26.0,
                    ),
                    decoration: BoxDecoration(
                      color: valueOrDefault<Color>(
                        () {
                          if (valueOrDefault<bool>(
                            widget.active,
                            true,
                          )) {
                            return context.colorScheme.onPrimary;
                          } else if (valueOrDefault<String>(
                                widget.variant,
                                'Android',
                              ) ==
                              'iOS 26+') {
                            return context.colorScheme
                                .surface;
                          } else {
                            return context.theme
                                .scaffoldBackgroundColor;
                          }
                        }(),
                        context.colorScheme.onPrimary,
                      ),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(valueOrDefault<double>(
                          valueOrDefault<String>(
                                    widget.variant,
                                    'Android',
                                  ) ==
                                  'iOS 26+'
                              ? 9999.0
                              : 13.0,
                          13.0,
                        )),
                        topRight: Radius.circular(valueOrDefault<double>(
                          valueOrDefault<String>(
                                    widget.variant,
                                    'Android',
                                  ) ==
                                  'iOS 26+'
                              ? 9999.0
                              : 13.0,
                          13.0,
                        )),
                        bottomLeft: Radius.circular(valueOrDefault<double>(
                          valueOrDefault<String>(
                                    widget.variant,
                                    'Android',
                                  ) ==
                                  'iOS 26+'
                              ? 9999.0
                              : 13.0,
                          13.0,
                        )),
                        bottomRight: Radius.circular(valueOrDefault<double>(
                          valueOrDefault<String>(
                                    widget.variant,
                                    'Android',
                                  ) ==
                                  'iOS 26+'
                              ? 9999.0
                              : 13.0,
                          13.0,
                        )),
                      ),
                      shape: BoxShape.rectangle,
                    ),
                  ),
                ),
              ),
            ),
          if (valueOrDefault<bool>(
            widget.labelPresent,
            true,
          ))
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 0.0, 0.0),
              child: Container(
                child: Text(
                  valueOrDefault<String>(
                    widget.label,
                    'Remember Me',
                  ),
                  style: context.textTheme.bodyMedium!.override(
                        font: GoogleFonts.inter(
                          fontWeight: context.textTheme
                              .bodyMedium!
                              .fontWeight,
                          fontStyle:
                              context.textTheme.bodyMedium!.fontStyle,
                        ),
                        color: context.colorScheme.onSurface,
                        letterSpacing: 0.0,
                        fontWeight:
                            context.textTheme.bodyMedium!.fontWeight,
                        fontStyle:
                            context.textTheme.bodyMedium!.fontStyle,
                        lineHeight: 1.43,
                      ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
