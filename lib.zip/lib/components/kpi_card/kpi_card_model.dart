import '../../core/utils/extensions.dart';
import 'kpi_card_widget.dart' show KpiCardWidget;
import 'package:flutter/material.dart';

class KpiCardModel extends FlutterFlowModel<KpiCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
