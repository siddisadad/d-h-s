import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'auth_tab_model.dart';
export 'auth_tab_model.dart';

class AuthTabWidget extends StatefulWidget {
  const AuthTabWidget({
    super.key,
    String? active,
    String? label,
  })  : this.active = active ?? 'true',
        this.label = label ?? 'Mobile Login';

  final String active;
  final String label;

  @override
  State<AuthTabWidget> createState() => _AuthTabWidgetState();
}

class _AuthTabWidgetState extends State<AuthTabWidget> {
  late AuthTabModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AuthTabModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.rectangle,
      ),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Container(
          child: Container(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: Text(
              valueOrDefault<String>(
                widget.label,
                'Mobile Login',
              ),
              style: context.textTheme.bodyMedium!.override(
                    font: GoogleFonts.inter(
                      fontWeight:
                          context.textTheme.bodyMedium!.fontWeight,
                      fontStyle:
                          context.textTheme.bodyMedium!.fontStyle,
                    ),
                    color: valueOrDefault<Color>(
                      valueOrDefault<String>(
                                widget.active,
                                'true',
                              ) ==
                              'false'
                          ? context.textTheme.bodySmall!.color
                          : context.colorScheme.primary,
                      context.colorScheme.primary,
                    ),
                    letterSpacing: 0.0,
                    fontWeight:
                        context.textTheme.bodyMedium!.fontWeight,
                    fontStyle:
                        context.textTheme.bodyMedium!.fontStyle,
                    lineHeight: 1.43,
                  ),
            ),
          ),
        ),
      ),
    );
  }
}
