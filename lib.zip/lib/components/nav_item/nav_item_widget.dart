import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'nav_item_model.dart';
export 'nav_item_model.dart';

class NavItemWidget extends StatefulWidget {
  const NavItemWidget({
    super.key,
    String? label,
    this.icon,
    String? target,
    bool? selected,
  })  : this.label = label ?? 'Home',
        this.target = target ?? 'MainDashboard',
        this.selected = selected ?? true;

  final String label;
  final Widget? icon;
  final String target;
  final bool selected;

  @override
  State<NavItemWidget> createState() => _NavItemWidgetState();
}

class _NavItemWidgetState extends State<NavItemWidget> {
  late NavItemModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NavItemModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(8.0, 4.0, 8.0, 4.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          widget.icon!,
          Text(
            valueOrDefault<String>(
              widget.label,
              'Home',
            ),
            style: context.textTheme.bodyMedium!.override(
                  font: GoogleFonts.inter(
                    fontWeight:
                        context.textTheme.bodyMedium!.fontWeight,
                    fontStyle:
                        context.textTheme.bodyMedium!.fontStyle,
                  ),
                  color: valueOrDefault<Color>(
                    valueOrDefault<bool>(
                      widget.selected,
                      true,
                    )
                        ? context.colorScheme.primary
                        : context.textTheme.bodySmall!.color,
                    context.colorScheme.primary,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      context.textTheme.bodyMedium!.fontWeight,
                  fontStyle: context.textTheme.bodyMedium!.fontStyle,
                  lineHeight: 1.43,
                ),
          ),
        ].divide(SizedBox(height: 2.0)),
      ),
    );
  }
}
