import '../../core/utils/extensions.dart';
import 'nav_item_widget.dart' show NavItemWidget;
import 'package:flutter/material.dart';

class NavItemModel extends FlutterFlowModel<NavItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
