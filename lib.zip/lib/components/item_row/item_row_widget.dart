import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'item_row_model.dart';
export 'item_row_model.dart';

class ItemRowWidget extends StatefulWidget {
  const ItemRowWidget({
    super.key,
    String? gst,
    String? name,
    String? price,
    String? qty,
    String? total,
    this.onDelete,
  })  : this.gst = gst ?? '18',
        this.name = name ?? 'TATA TISCON TMT Bars 12mm',
        this.price = price ?? '65,400',
        this.qty = qty ?? '100',
        this.total = total ?? '7,84,800';

  final String gst;
  final String name;
  final String price;
  final String qty;
  final String total;
  final VoidCallback? onDelete;

  @override
  State<ItemRowWidget> createState() => _ItemRowWidgetState();
}

class _ItemRowWidgetState extends State<ItemRowWidget> {
  late ItemRowModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ItemRowModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 8.0),
      child: Container(
        child: Container(
          decoration: BoxDecoration(
            color: context.colorScheme.surface,
            borderRadius: BorderRadius.circular(12.0),
            shape: BoxShape.rectangle,
            border: Border.all(
              color: context.colorScheme.outline,
              width: 1.0,
            ),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Container(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        flex: 1,
                        child: Text(
                          valueOrDefault<String>(
                            widget.name,
                            'TATA TISCON TMT Bars 12mm',
                          ),
                          maxLines: 1,
                          style:
                              context.textTheme.titleSmall!.override(
                                    font: GoogleFonts.plusJakartaSans(
                                      fontWeight: FontWeight.bold,
                                      fontStyle: context.textTheme
                                          .titleSmall!
                                          .fontStyle,
                                    ),
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.bold,
                                    fontStyle: context.textTheme
                                        .titleSmall!
                                        .fontStyle,
                                    lineHeight: 1.43,
                                  ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          Icons.delete_outline_rounded,
                          color: context.colorScheme.error,
                          size: 20.0,
                        ),
                        onPressed: () async {
                          widget.onDelete?.call();
                        },
                      ),
                    ].divide(SizedBox(width: context.tokens.space16)),
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        flex: 1,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              valueOrDefault<String>(
                                'Qty: ${widget.qty}',
                                'Qty: 100',
                              ),
                              style: context.textTheme
                                  .bodySmall!
                                  .override(
                                    font: GoogleFonts.inter(
                                      fontWeight: context.textTheme
                                          .bodySmall!
                                          .fontWeight,
                                      fontStyle: context.textTheme
                                          .bodySmall!
                                          .fontStyle,
                                    ),
                                    color: context.textTheme.bodySmall!.color,
                                    letterSpacing: 0.0,
                                    fontWeight: context.textTheme
                                        .bodySmall!
                                        .fontWeight,
                                    fontStyle: context.textTheme
                                        .bodySmall!
                                        .fontStyle,
                                    lineHeight: 1.33,
                                  ),
                            ),
                            Text(
                              valueOrDefault<String>(
                                'Price: ₹${widget.price}',
                                'Price: ₹65,400',
                              ),
                              style: context.textTheme
                                  .bodySmall!
                                  .override(
                                    font: GoogleFonts.inter(
                                      fontWeight: context.textTheme
                                          .bodySmall!
                                          .fontWeight,
                                      fontStyle: context.textTheme
                                          .bodySmall!
                                          .fontStyle,
                                    ),
                                    color: context.textTheme.bodySmall!.color,
                                    letterSpacing: 0.0,
                                    fontWeight: context.textTheme
                                        .bodySmall!
                                        .fontWeight,
                                    fontStyle: context.textTheme
                                        .bodySmall!
                                        .fontStyle,
                                    lineHeight: 1.33,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            valueOrDefault<String>(
                              'GST: ${widget.gst}%',
                              'GST: 18%',
                            ),
                            style:
                                context.textTheme.bodySmall!.override(
                                      font: GoogleFonts.inter(
                                        fontWeight: context.textTheme
                                            .bodySmall!
                                            .fontWeight,
                                        fontStyle: context.textTheme
                                            .bodySmall!
                                            .fontStyle,
                                      ),
                                      color: context.textTheme.bodySmall!.color,
                                      letterSpacing: 0.0,
                                      fontWeight: context.textTheme
                                          .bodySmall!
                                          .fontWeight,
                                      fontStyle: context.textTheme
                                          .bodySmall!
                                          .fontStyle,
                                      lineHeight: 1.33,
                                    ),
                          ),
                          Text(
                            valueOrDefault<String>(
                              '₹${widget.total}',
                              '₹7,84,800',
                            ),
                            style: context.textTheme
                                .bodyMedium!
                                .override(
                                  font: GoogleFonts.inter(
                                    fontWeight: FontWeight.w600,
                                    fontStyle: context.textTheme
                                        .bodyMedium!
                                        .fontStyle,
                                  ),
                                  color: context.colorScheme.primary,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w600,
                                  fontStyle: context.textTheme
                                      .bodyMedium!
                                      .fontStyle,
                                  lineHeight: 1.43,
                                ),
                          ),
                        ],
                      ),
                    ].divide(SizedBox(width: context.tokens.space16)),
                  ),
                ].divide(SizedBox(height: context.tokens.space8)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
