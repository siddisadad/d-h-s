import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'settings_item_model.dart';
export 'settings_item_model.dart';

class SettingsItemWidget extends StatefulWidget {
  const SettingsItemWidget({
    super.key,
    bool? hasSubtitle,
    this.icon,
    String? label,
    String? subtitle,
  })  : this.hasSubtitle = hasSubtitle ?? true,
        this.label = label ?? 'Business Details',
        this.subtitle = subtitle ?? 'Name, Address, Contact info';

  final bool hasSubtitle;
  final Widget? icon;
  final String label;
  final String subtitle;

  @override
  State<SettingsItemWidget> createState() => _SettingsItemWidgetState();
}

class _SettingsItemWidgetState extends State<SettingsItemWidget> {
  late SettingsItemModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SettingsItemModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: context.colorScheme.surface,
        shape: BoxShape.rectangle,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(24.0, 16.0, 24.0, 16.0),
        child: Container(
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 40.0,
                height: 40.0,
                decoration: BoxDecoration(
                  color: context.colorScheme.primary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12.0),
                  shape: BoxShape.rectangle,
                ),
                alignment: AlignmentDirectional(0.0, 0.0),
                child: widget.icon!,
              ),
              Expanded(
                flex: 1,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      valueOrDefault<String>(
                        widget.label,
                        'Business Details',
                      ),
                      style: context.textTheme.bodyMedium!.override(
                            font: GoogleFonts.inter(
                              fontWeight: FontWeight.w500,
                              fontStyle: context.textTheme
                                  .bodyMedium!
                                  .fontStyle,
                            ),
                            color: context.colorScheme.onSurface,
                            letterSpacing: 0.0,
                            fontWeight: FontWeight.w500,
                            fontStyle: context.textTheme
                                .bodyMedium!
                                .fontStyle,
                            lineHeight: 1.43,
                          ),
                    ),
                    if (valueOrDefault<bool>(
                      widget.hasSubtitle,
                      true,
                    ))
                      Text(
                        valueOrDefault<String>(
                          widget.subtitle,
                          'Name, Address, Contact info',
                        ),
                        style: context.textTheme.labelSmall!.override(
                              font: GoogleFonts.inter(
                                fontWeight: context.textTheme
                                    .labelSmall!
                                    .fontWeight,
                                fontStyle: context.textTheme
                                    .labelSmall!
                                    .fontStyle,
                              ),
                              color: context.textTheme.bodySmall!.color,
                              letterSpacing: 0.0,
                              fontWeight: context.textTheme
                                  .labelSmall!
                                  .fontWeight,
                              fontStyle: context.textTheme
                                  .labelSmall!
                                  .fontStyle,
                              lineHeight: 1.45,
                            ),
                      ),
                  ].divide(SizedBox(height: context.tokens.space4)),
                ),
              ),
              Icon(
                Icons.chevron_right_rounded,
                color: context.colorScheme.outline,
                size: 20.0,
              ),
            ].divide(SizedBox(width: context.tokens.space16)),
          ),
        ),
      ),
    );
  }
}
