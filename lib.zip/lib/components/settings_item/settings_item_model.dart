import '../../core/utils/extensions.dart';
import 'settings_item_widget.dart' show SettingsItemWidget;
import 'package:flutter/material.dart';

class SettingsItemModel extends FlutterFlowModel<SettingsItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
