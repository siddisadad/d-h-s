import '/components/nav_item/nav_item_widget.dart';
import '../../core/design_system/theme/app_theme.dart';
import '../../core/utils/extensions.dart';
import 'package:flutter/material.dart';
import 'bottom_nav_child_model.dart';
export 'bottom_nav_child_model.dart';

class BottomNavChildWidget extends StatefulWidget {
  const BottomNavChildWidget({super.key});

  @override
  State<BottomNavChildWidget> createState() => _BottomNavChildWidgetState();
}

class _BottomNavChildWidgetState extends State<BottomNavChildWidget> {
  late BottomNavChildModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BottomNavChildModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        wrapWithModel(
          model: _model.navItemModel1,
          updateCallback: () => safeSetState(() {}),
          child: NavItemWidget(
            label: 'Home',
            icon: Icon(
              Icons.dashboard_rounded,
              color: context.colorScheme.onSurface,
              size: 24.0,
            ),
            target: 'MainDashboard',
            selected: true,
          ),
        ),
        wrapWithModel(
          model: _model.navItemModel2,
          updateCallback: () => safeSetState(() {}),
          child: NavItemWidget(
            label: 'Inventory',
            icon: Icon(
              Icons.inventory_rounded,
              color: context.colorScheme.onSurface,
              size: 24.0,
            ),
            target: 'ProductInventory',
            selected: false,
          ),
        ),
        wrapWithModel(
          model: _model.navItemModel3,
          updateCallback: () => safeSetState(() {}),
          child: NavItemWidget(
            label: 'Sales',
            icon: Icon(
              Icons.receipt_long_rounded,
              color: context.colorScheme.onSurface,
              size: 24.0,
            ),
            target: 'SalesInvoiceEntry',
            selected: false,
          ),
        ),
        wrapWithModel(
          model: _model.navItemModel4,
          updateCallback: () => safeSetState(() {}),
          child: NavItemWidget(
            label: 'Finance',
            icon: Icon(
              Icons.account_balance_rounded,
              color: context.colorScheme.onSurface,
              size: 24.0,
            ),
            target: 'FinanceCashBook',
            selected: false,
          ),
        ),
        wrapWithModel(
          model: _model.navItemModel5,
          updateCallback: () => safeSetState(() {}),
          child: NavItemWidget(
            label: 'Settings',
            icon: Icon(
              Icons.settings_rounded,
              color: context.colorScheme.onSurface,
              size: 24.0,
            ),
            target: 'BusinessSettings',
            selected: false,
          ),
        ),
      ],
    );
  }
}
