import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_web_plugins/url_strategy.dart';
import 'core/design_system/theme/app_theme.dart';
import 'core/router/app_router.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  usePathUrlStrategy();

  // Any other initialization (Firebase, Secure Storage, etc.) should go here
  
  runApp(
    const ProviderScope(
      child: MyApp(),
    ),
  );
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // We'll use a specific name for the router provider to avoid conflicts
    final router = ref.watch(appRouterWidgetProvider);

    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'Deshmukh Hardware & Steel ERP',
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.light, // Default to light as per spec
      routerConfig: router,
    );
  }
}
