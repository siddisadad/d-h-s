// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sales_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$salesInvoiceNotifierHash() =>
    r'd8316e5540e0ff324dbe77d394cf109468349a3b';

/// See also [SalesInvoiceNotifier].
@ProviderFor(SalesInvoiceNotifier)
final salesInvoiceNotifierProvider = AutoDisposeNotifierProvider<
    SalesInvoiceNotifier, SalesInvoiceDraft>.internal(
  SalesInvoiceNotifier.new,
  name: r'salesInvoiceNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$salesInvoiceNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SalesInvoiceNotifier = AutoDisposeNotifier<SalesInvoiceDraft>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
