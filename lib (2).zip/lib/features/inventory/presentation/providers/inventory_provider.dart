import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:flutter/foundation.dart';
import '../../domain/entities/product.dart';
import '../../domain/usecases/get_products.dart';
import '../../../../core/di/injection_container.dart';
import '../../../dashboard/presentation/providers/activity_provider.dart';
import '../../../dashboard/domain/entities/activity.dart' as activity;

part 'inventory_provider.g.dart';

@riverpod
class InventoryNotifier extends _$InventoryNotifier {
  @override
  Future<List<Product>> build() async {
    return _fetchFromApi();
  }

  String _currentCategory = 'All Items';
  String _searchQuery = '';

  String get currentCategory => _currentCategory;
  String get searchQuery => _searchQuery;

  Future<List<Product>> _fetchFromApi() async {
    try {
      debugPrint('🌐 [Inventory] Fetching from API...');
      final getProductsUseCase = sl.getProductsUseCase;
      final result = await getProductsUseCase(GetProductsParams(category: null));

      return result.fold(
        (failure) {
          debugPrint('❌ [Inventory] API Fetch Failed: ${failure.message}');
          throw Exception(failure.message);
        },
        (products) {
          debugPrint('✅ [Inventory] API Fetch Complete. Records: ${products.length}');
          
          if (_currentCategory == 'All Items') {
            return products;
          }
          return products.where((p) => p.category.toLowerCase() == _currentCategory.toLowerCase()).toList();
        },
      );
    } catch (e) {
      debugPrint('⚠️ [Inventory] Error: $e');
      rethrow;
    }
  }

  void setCategory(String category) {
    _currentCategory = category;
    ref.invalidateSelf();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    ref.notifyListeners(); 
  }

  Future<void> addProduct(Product product) async {
    state = const AsyncLoading();
    final result = await sl.inventoryRepository.createProduct(product);
    
    state = await AsyncValue.guard(() async {
      return result.fold(
        (failure) => throw Exception(failure.message),
        (success) {
          ref.read(activityNotifierProvider.notifier).addActivity(
            'New Product Added',
            '${product.name} (SKU: ${product.sku})',
            activity.ActivityType.stockAdjustment,
          );
          return _fetchFromApi();
        },
      );
    });
  }

  Future<void> updateProduct(Product product) async {
    state = const AsyncLoading();
    final result = await sl.inventoryRepository.updateProduct(product);
    
    state = await AsyncValue.guard(() async {
      return result.fold(
        (failure) => throw Exception(failure.message),
        (success) {
          ref.read(activityNotifierProvider.notifier).addActivity(
            'Product Updated',
            '${product.name} details modified',
            activity.ActivityType.stockAdjustment,
          );
          return _fetchFromApi();
        },
      );
    });
  }

  Future<void> deleteProduct(String sku) async {
    state = const AsyncLoading();
    final result = await sl.inventoryRepository.deleteProduct(sku);
    
    state = await AsyncValue.guard(() async {
      return result.fold(
        (failure) => throw Exception(failure.message),
        (success) {
          ref.read(activityNotifierProvider.notifier).addActivity(
            'Product Deleted',
            'SKU: $sku removed from system',
            activity.ActivityType.stockAdjustment,
          );
          return _fetchFromApi();
        },
      );
    });
  }

  Future<void> adjustStock(String sku, double quantity) async {
    // Note: In Cloud-Only mode, we would call an API endpoint here.
    // This is currently in-memory/simulated until updateStockUseCase is added to sl.
    
    ref.read(activityNotifierProvider.notifier).addActivity(
      'Stock Adjusted',
      'SKU: $sku ${quantity >= 0 ? "+" : ""}$quantity',
      activity.ActivityType.stockAdjustment,
    );

    ref.invalidateSelf();
  }
}

@riverpod
List<Product> filteredProducts(FilteredProductsRef ref) {
  final productsAsync = ref.watch(inventoryNotifierProvider);
  final notifier = ref.watch(inventoryNotifierProvider.notifier);
  final query = notifier.searchQuery.toLowerCase();

  return productsAsync.maybeWhen(
    data: (products) {
      if (query.isEmpty) return products;
      return products.where((p) => 
        p.name.toLowerCase().contains(query) || 
        p.sku.toLowerCase().contains(query)
      ).toList();
    },
    orElse: () => [],
  );
}
