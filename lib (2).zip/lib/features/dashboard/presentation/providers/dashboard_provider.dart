import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/entities/dashboard_stats.dart';
import '../../../../core/usecases/usecase.dart';
import '../../../../core/di/injection_container.dart';

part 'dashboard_provider.g.dart';

@riverpod
class DashboardStatsNotifier extends _$DashboardStatsNotifier {
  @override
  Future<DashboardStats?> build() async {
    // Initial fetch
    return _fetchStats();
  }

  Future<DashboardStats?> _fetchStats() async {
    final getStatsUseCase = sl.getStatsUseCase;
    
    final result = await getStatsUseCase(NoParams());
    
    return result.fold(
      (failure) => throw Exception(failure.message),
      (stats) => stats,
    );
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _fetchStats());
  }
}
