// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dashboard_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$dashboardStatsNotifierHash() =>
    r'eda7ff512713546d6509c736adc598a64c5f620e';

/// See also [DashboardStatsNotifier].
@ProviderFor(DashboardStatsNotifier)
final dashboardStatsNotifierProvider = AutoDisposeAsyncNotifierProvider<
    DashboardStatsNotifier, DashboardStats?>.internal(
  DashboardStatsNotifier.new,
  name: r'dashboardStatsNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$dashboardStatsNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$DashboardStatsNotifier = AutoDisposeAsyncNotifier<DashboardStats?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
