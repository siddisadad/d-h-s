// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'global_search_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$globalSearchHash() => r'c70d76ceed94182e18a2ddeddf34ddf1e4985653';

/// See also [GlobalSearch].
@ProviderFor(GlobalSearch)
final globalSearchProvider = AutoDisposeNotifierProvider<GlobalSearch,
    AsyncValue<List<SearchResult>>>.internal(
  GlobalSearch.new,
  name: r'globalSearchProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$globalSearchHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$GlobalSearch = AutoDisposeNotifier<AsyncValue<List<SearchResult>>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
