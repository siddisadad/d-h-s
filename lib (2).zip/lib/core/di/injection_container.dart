import 'package:flutter/foundation.dart';
import '../../features/dashboard/data/datasources/dashboard_remote_data_source.dart';
import '../../features/dashboard/data/repositories/dashboard_repository_impl.dart';
import '../../features/dashboard/domain/usecases/get_dashboard_stats.dart';
import '../../features/crm/data/datasources/crm_remote_data_source.dart';
import '../../features/crm/data/repositories/crm_repository_impl.dart';
import '../../features/crm/domain/usecases/get_contacts.dart';
import '../../features/inventory/data/datasources/inventory_remote_data_source.dart';
import '../../features/inventory/data/repositories/inventory_repository_impl.dart';
import '../../features/inventory/domain/usecases/get_products.dart';
import '../../features/sales/data/datasources/sales_remote_data_source.dart';
import '../../features/sales/data/repositories/sales_repository_impl.dart';
import '../../features/sales/domain/usecases/create_invoice.dart';
import '../../features/purchases/data/datasources/purchase_remote_data_source.dart';
import '../../features/purchases/data/repositories/purchase_repository_impl.dart';
import '../../features/employees/data/datasources/employee_remote_data_source.dart';
import '../../features/employees/data/repositories/employee_repository_impl.dart';
import '../../features/finance/data/datasources/finance_remote_data_source.dart';
import '../../features/finance/data/repositories/finance_repository_impl.dart';
import '../../features/authentication/data/datasources/auth_remote_data_source.dart';
import '../../features/authentication/data/datasources/auth_mock_data_source.dart';
import '../../features/authentication/data/repositories/auth_repository_impl.dart';
import '../config/app_config.dart';
import '../network/api_client.dart';

class InjectionContainer {
  static final InjectionContainer _instance = InjectionContainer._internal();
  factory InjectionContainer() => _instance;
  InjectionContainer._internal();

  bool _isInitialized = false;

  // Use Cases / Repositories bridge
  late GetProducts getProductsUseCase;
  late GetDashboardStats getStatsUseCase;
  late CreateInvoice createInvoiceUseCase;
  late GetContacts getContactsUseCase;
  late PurchaseRepositoryImpl purchaseRepository;
  late EmployeeRepositoryImpl employeeRepository;
  late FinanceRepositoryImpl financeRepository;
  late AuthRepositoryImpl authRepository;
  late InventoryRepositoryImpl inventoryRepository;

  void init(ApiClient client) {
    if (_isInitialized) {
      debugPrint('📦 [DI] Service Locator already initialized');
      return;
    }

    final useMocks = AppConfig.useMocks;
    debugPrint('📦 [DI] Initializing Service Locator (Mocks: $useMocks)...');

    // Authentication
    final authDataSource = useMocks 
        ? AuthMockDataSource() 
        : AuthRemoteDataSourceImpl(client);
    authRepository = AuthRepositoryImpl(authDataSource);

    // Inventory
    final inventoryDataSource = useMocks
        ? InventoryMockDataSourceImpl()
        : InventoryRemoteDataSourceImpl(client);
    inventoryRepository = InventoryRepositoryImpl(remoteDataSource: inventoryDataSource);
    getProductsUseCase = GetProducts(inventoryRepository);

    // Dashboard
    final dashboardDataSource = DashboardRemoteDataSourceImpl(client);
    final dashboardRepository = DashboardRepositoryImpl(remoteDataSource: dashboardDataSource);
    getStatsUseCase = GetDashboardStats(dashboardRepository);

    // Sales
    final salesDataSource = SalesMockDataSourceImpl();
    final salesRepository = SalesRepositoryImpl(remoteDataSource: salesDataSource);
    createInvoiceUseCase = CreateInvoice(salesRepository);

    // CRM
    final crmDataSource = CrmRemoteDataSourceImpl(client);
    final crmRepository = CrmRepositoryImpl(remoteDataSource: crmDataSource);
    getContactsUseCase = GetContacts(crmRepository);

    // Purchases
    final purchaseDataSource = PurchaseRemoteDataSourceImpl(client);
    purchaseRepository = PurchaseRepositoryImpl(remoteDataSource: purchaseDataSource);

    // Employees
    final employeeDataSource = EmployeeRemoteDataSourceImpl(client);
    employeeRepository = EmployeeRepositoryImpl(remoteDataSource: employeeDataSource);

    // Finance
    final financeDataSource = FinanceRemoteDataSourceImpl(client);
    financeRepository = FinanceRepositoryImpl(remoteDataSource: financeDataSource);

    _isInitialized = true;
    debugPrint('✅ [DI] Service Locator Ready');
  }
}

final sl = InjectionContainer();
