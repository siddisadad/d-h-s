// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pdf_service.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$pdfServiceHash() => r'60516e76e05ed1d0772313959ac6f918ce0b4bb7';

/// See also [PdfService].
@ProviderFor(PdfService)
final pdfServiceProvider =
    AutoDisposeNotifierProvider<PdfService, void>.internal(
  PdfService.new,
  name: r'pdfServiceProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$pdfServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PdfService = AutoDisposeNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
